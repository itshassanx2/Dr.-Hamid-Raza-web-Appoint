import fs from 'fs';
import path from 'path';

export interface DoctorProfile {
  name: string;
  qualifications: string;
  specialization: string;
  designation: string;
  hospitalAffiliation: string;
  about: string;
  experienceYears: number;
  pmdcNumber: string;
  phone: string;
  email: string;
}

export interface ClinicLocation {
  id: string;
  name: string;
  tagline: string;
  address: string;
  city: string;
  days: string;
  timings: string;
  fee: number;
  phone: string;
  isDefault: boolean;
  type: 'hospital' | 'private_clinic' | 'telehealth';
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'General' | 'Appointments' | 'Vaccination' | 'Newborn Care';
}

export interface ClinicSettings {
  doctor: DoctorProfile;
  locations: ClinicLocation[];
  appointmentIntervalMinutes: number;
  maxPatientsPerSlot: number;
  emergencyContact: string;
  faqs: FAQItem[];
}

export interface Appointment {
  id: string;
  bookingReference: string; // e.g. HR-8421
  tokenNumber: number; // 1, 2, 3... for the day
  patientId?: string;
  patientName: string;
  patientAgeYears: number;
  patientAgeMonths: number;
  patientGender: 'Male' | 'Female';
  guardianName: string;
  guardianRelation: 'Father' | 'Mother' | 'Guardian';
  guardianPhone: string;
  guardianEmail?: string;
  clinicLocationId: string;
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g. "06:30 PM"
  reasonForVisit: string;
  isFollowUp: boolean;
  status: 'confirmed' | 'in-queue' | 'in-consultation' | 'completed' | 'cancelled' | 'no-show';
  paymentStatus: 'pending' | 'paid' | 'waived';
  fee: number;
  notes?: string;
  createdAt: string;
}

export interface Patient {
  id: string;
  mrn: string; // e.g. MR-2026-101
  childName: string;
  dob: string;
  gender: 'Male' | 'Female';
  bloodGroup: string;
  allergies: string[];
  guardianName: string;
  guardianPhone: string;
  address: string;
  birthWeightKg?: number;
  gestationalWeeks?: number;
  historyNotes: string;
  createdAt: string;
}

export interface Vitals {
  weightKg?: number;
  heightCm?: number;
  headCircumferenceCm?: number;
  temperatureF?: number;
  spo2?: number;
  respiratoryRate?: number;
  heartRate?: number;
}

export interface Medication {
  medicineName: string;
  form: 'Syrup' | 'Drops' | 'Suspension' | 'Sachet' | 'Tablet' | 'Inhaler' | 'Ointment' | 'Respules';
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
}

export interface Prescription {
  id: string;
  prescriptionNumber: string;
  appointmentId?: string;
  patientId: string;
  patientName: string;
  ageDisplay: string;
  gender: 'Male' | 'Female';
  guardianName: string;
  date: string;
  vitals: Vitals;
  chiefComplaints: string[];
  diagnosis: string;
  clinicalNotes?: string;
  medications: Medication[];
  advice: string[];
  investigations?: string[];
  followUpDate?: string;
  doctorName: string;
  doctorDesignation: string;
  createdAt: string;
}

export interface VaccineRecord {
  id: string;
  patientId: string;
  vaccineName: string;
  targetAge: string;
  dueDate: string;
  administeredDate?: string;
  status: 'pending' | 'completed' | 'delayed' | 'skipped';
  batchNo?: string;
  notes?: string;
}

export interface DatabaseSchema {
  settings: ClinicSettings;
  appointments: Appointment[];
  patients: Patient[];
  prescriptions: Prescription[];
  vaccinations: VaccineRecord[];
}

export const defaultSettings: ClinicSettings = {
  doctor: {
    name: 'Dr. Hamid Raza',
    qualifications: 'M.B.B.S. (KE), MD (KE) Pediatrics',
    specialization: 'Consultant Child Specialist & Neonatologist',
    designation: 'Senior Registrar, Mayo Hospital Lahore',
    hospitalAffiliation: 'King Edward Medical University / Mayo Hospital Lahore',
    about: 'Dr. Hamid Raza is an accomplished Consultant Pediatrician and Neonatologist serving as Senior Registrar at Mayo Hospital Lahore. A distinguished alumnus of the prestigious King Edward Medical University with both MBBS and MD Pediatrics, Dr. Raza has dedicated his career to delivering advanced clinical care for newborns, infants, and children with complex medical conditions.',
    experienceYears: 12,
    pmdcNumber: '58412-P (PMDC Registered)',
    phone: '+92 300 4567890',
    email: 'clinic@drhamidraza.med',
  },
  locations: [
    {
      id: 'loc-mayo',
      name: 'Mayo Hospital Lahore — Pediatric OPD',
      tagline: 'Morning Institutional Clinical Services',
      address: 'Hospital Road, Anarkali, Mayo Hospital, Lahore, Punjab, Pakistan',
      city: 'Lahore',
      days: 'Monday to Saturday',
      timings: '08:30 AM – 01:30 PM',
      fee: 0,
      phone: '+92 42 99211100',
      isDefault: true,
      type: 'hospital',
    },
    {
      id: 'loc-executive',
      name: 'Executive Evening Pediatric Clinic',
      tagline: 'Private Evening Consultations & Neonatal Care',
      address: 'Suite 204, MedCare Towers, Main Boulevard, Gulberg III / Jail Road, Lahore',
      city: 'Lahore',
      days: 'Monday to Friday',
      timings: '05:30 PM – 09:30 PM',
      fee: 2500,
      phone: '+92 321 8899770',
      isDefault: false,
      type: 'private_clinic',
    },
    {
      id: 'loc-telehealth',
      name: 'Online Pediatric Tele-Consultation',
      tagline: 'Secure Video Consultation for Remote Patients & Follow-ups',
      address: 'Online via High-Definition Secure Telehealth Video Portal',
      city: 'Lahore / Nationwide',
      days: 'Tuesday & Thursday',
      timings: '03:00 PM – 05:00 PM',
      fee: 2000,
      phone: '+92 300 4567890',
      isDefault: false,
      type: 'telehealth',
    },
  ],
  appointmentIntervalMinutes: 20,
  maxPatientsPerSlot: 2,
  emergencyContact: '+92 42 99211100 (Mayo Hospital Emergency 24/7)',
  faqs: [
    {
      id: 'faq-1',
      question: 'What documents or records should I bring for my child\'s first visit?',
      answer: 'Please bring your child\'s birth summary/discharge card, immunization/vaccination yellow card, any previous medical prescriptions, and growth records. This helps Dr. Hamid Raza evaluate the complete developmental history.',
      category: 'Appointments',
    },
    {
      id: 'faq-2',
      question: 'What is Dr. Hamid Raza\'s clinical background?',
      answer: 'Dr. Hamid Raza completed both his M.B.B.S. and MD Pediatrics from the renowned King Edward Medical University (KE). He currently serves as Senior Registrar at Mayo Hospital Lahore, specializing in neonatal intensive care, pediatric infections, and infant developmental milestones.',
      category: 'General',
    },
    {
      id: 'faq-3',
      question: 'How do I track our booked appointment and queue status?',
      answer: 'Once you book online, you will receive an instant Booking Reference ID (e.g. HR-1024) and Token Number. You can check real-time queue status directly using the "Track Booking" tab on this portal.',
      category: 'Appointments',
    },
    {
      id: 'faq-4',
      question: 'Are newborn vaccinations available at the clinic?',
      answer: 'Yes, both government EPI schedule vaccines and international recommended pediatric vaccines (including Rotavirus, Typhoid conjugate, Varicella, and Influenza) are administered under sterile, cold-chain compliant pediatric protocols.',
      category: 'Vaccination',
    },
    {
      id: 'faq-5',
      question: 'What should I do in case of a pediatric emergency after clinic hours?',
      answer: 'For acute emergencies such as high fever with seizures, severe respiratory distress, or dehydration, proceed immediately to the 24/7 Mayo Hospital Pediatric Emergency Department or call our emergency desk.',
      category: 'Newborn Care',
    },
  ],
};
