import fs from 'fs';
import path from 'path';
import {
  DatabaseSchema,
  defaultSettings,
  ClinicSettings,
  Appointment,
  Patient,
  Prescription,
  VaccineRecord,
} from './initialData.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'clinic_data.json');

const samplePatients: Patient[] = [
  {
    id: 'pat-1',
    mrn: 'MR-2026-1001',
    childName: 'Muhammad Hamza',
    dob: '2025-08-14',
    gender: 'Male',
    bloodGroup: 'B+',
    allergies: ['Penicillin (mild rash)'],
    guardianName: 'Tariq Mehmood',
    guardianPhone: '03001234567',
    address: 'Model Town, Lahore',
    birthWeightKg: 3.2,
    gestationalWeeks: 39,
    historyNotes: 'Term baby, normal spontaneous delivery. Treated for mild neonatal jaundice on day 4 with phototherapy.',
    createdAt: '2026-01-10T10:00:00.000Z',
  },
  {
    id: 'pat-2',
    mrn: 'MR-2026-1002',
    childName: 'Ayesha Fatima',
    dob: '2024-03-22',
    gender: 'Female',
    bloodGroup: 'O+',
    allergies: [],
    guardianName: 'Usman Ali',
    guardianPhone: '03219876543',
    address: 'Johar Town, Lahore',
    birthWeightKg: 2.9,
    gestationalWeeks: 38,
    historyNotes: 'Recurrent wheezing with seasonal weather changes. Moderate reactive airway disease.',
    createdAt: '2026-01-15T14:30:00.000Z',
  },
  {
    id: 'pat-3',
    mrn: 'MR-2026-1003',
    childName: 'Zainab Noor',
    dob: '2026-09-05',
    gender: 'Female',
    bloodGroup: 'A+',
    allergies: [],
    guardianName: 'Farhan Khalid',
    guardianPhone: '03335551234',
    address: 'Gulshan-e-Ravi, Lahore',
    birthWeightKg: 3.1,
    gestationalWeeks: 40,
    historyNotes: 'Newborn routine growth assessment. Infantile colic symptoms.',
    createdAt: '2026-10-01T11:00:00.000Z',
  },
  {
    id: 'pat-4',
    mrn: 'MR-2026-1004',
    childName: 'Ali Raza Khan',
    dob: '2022-11-10',
    gender: 'Male',
    bloodGroup: 'AB+',
    allergies: ['Dust mites'],
    guardianName: 'Bilal Khan',
    guardianPhone: '03024443322',
    address: 'DHA Phase 5, Lahore',
    birthWeightKg: 3.4,
    gestationalWeeks: 39,
    historyNotes: 'Preschool health checkup, mild viral URTI.',
    createdAt: '2026-10-18T09:15:00.000Z',
  },
];

// Today's date in local ISO format YYYY-MM-DD
const todayStr = new Date().toISOString().split('T')[0];

const sampleAppointments: Appointment[] = [
  {
    id: 'apt-101',
    bookingReference: 'HR-8101',
    tokenNumber: 1,
    patientId: 'pat-1',
    patientName: 'Muhammad Hamza',
    patientAgeYears: 1,
    patientAgeMonths: 2,
    patientGender: 'Male',
    guardianName: 'Tariq Mehmood',
    guardianRelation: 'Father',
    guardianPhone: '03001234567',
    guardianEmail: 'tariq.m@example.com',
    clinicLocationId: 'loc-executive',
    date: todayStr,
    timeSlot: '05:30 PM',
    reasonForVisit: 'Persistent dry cough and low-grade fever for 3 days',
    isFollowUp: false,
    status: 'in-consultation',
    paymentStatus: 'paid',
    fee: 2500,
    notes: 'Father requested chest auscultation',
    createdAt: '2026-11-01T12:00:00.000Z',
  },
  {
    id: 'apt-102',
    bookingReference: 'HR-8102',
    tokenNumber: 2,
    patientId: 'pat-2',
    patientName: 'Ayesha Fatima',
    patientAgeYears: 2,
    patientAgeMonths: 7,
    patientGender: 'Female',
    guardianName: 'Usman Ali',
    guardianRelation: 'Father',
    guardianPhone: '03219876543',
    guardianEmail: 'usman.ali@example.com',
    clinicLocationId: 'loc-executive',
    date: todayStr,
    timeSlot: '06:00 PM',
    reasonForVisit: 'Wheezing checkup & asthma inhaler spacer review',
    isFollowUp: true,
    status: 'in-queue',
    paymentStatus: 'paid',
    fee: 2500,
    notes: 'In waiting area since 5:50 PM',
    createdAt: '2026-11-01T14:30:00.000Z',
  },
  {
    id: 'apt-103',
    bookingReference: 'HR-8103',
    tokenNumber: 3,
    patientId: 'pat-3',
    patientName: 'Zainab Noor',
    patientAgeYears: 0,
    patientAgeMonths: 2,
    patientGender: 'Female',
    guardianName: 'Farhan Khalid',
    guardianRelation: 'Father',
    guardianPhone: '03335551234',
    guardianEmail: '',
    clinicLocationId: 'loc-executive',
    date: todayStr,
    timeSlot: '06:30 PM',
    reasonForVisit: '2-Month EPI vaccination & excessive evening crying (colic)',
    isFollowUp: false,
    status: 'confirmed',
    paymentStatus: 'pending',
    fee: 2500,
    notes: 'Mother wants formula milk guidance',
    createdAt: '2026-11-02T08:15:00.000Z',
  },
  {
    id: 'apt-104',
    bookingReference: 'HR-8104',
    tokenNumber: 4,
    patientId: 'pat-4',
    patientName: 'Ali Raza Khan',
    patientAgeYears: 4,
    patientAgeMonths: 0,
    patientGender: 'Male',
    guardianName: 'Bilal Khan',
    guardianRelation: 'Father',
    guardianPhone: '03024443322',
    guardianEmail: 'bilal.khan@example.com',
    clinicLocationId: 'loc-executive',
    date: todayStr,
    timeSlot: '07:00 PM',
    reasonForVisit: 'Poor appetite and weight gain concerns',
    isFollowUp: false,
    status: 'confirmed',
    paymentStatus: 'pending',
    fee: 2500,
    notes: 'Bring previous growth charts',
    createdAt: '2026-11-02T10:45:00.000Z',
  },
  {
    id: 'apt-105',
    bookingReference: 'HR-8099',
    tokenNumber: 5,
    patientName: 'Baby of Sana',
    patientAgeYears: 0,
    patientAgeMonths: 1,
    patientGender: 'Female',
    guardianName: 'Sana Tariq',
    guardianRelation: 'Mother',
    guardianPhone: '03451122334',
    clinicLocationId: 'loc-mayo',
    date: todayStr,
    timeSlot: '10:00 AM',
    reasonForVisit: 'Neonatal umbilical cord healing & weight check',
    isFollowUp: true,
    status: 'completed',
    paymentStatus: 'waived',
    fee: 0,
    notes: 'Discharged from nursery last week',
    createdAt: '2026-11-01T09:00:00.000Z',
  },
];

const samplePrescriptions: Prescription[] = [
  {
    id: 'rx-201',
    prescriptionNumber: 'RX-26-0841',
    appointmentId: 'apt-105',
    patientId: 'pat-1',
    patientName: 'Muhammad Hamza',
    ageDisplay: '1 Year 2 Months',
    gender: 'Male',
    guardianName: 'Tariq Mehmood',
    date: todayStr,
    vitals: {
      weightKg: 10.4,
      heightCm: 79,
      headCircumferenceCm: 46.5,
      temperatureF: 99.2,
      spo2: 98,
      respiratoryRate: 26,
    },
    chiefComplaints: ['Dry nocturnal cough x 3 days', 'Mild coryza & nasal congestion'],
    diagnosis: 'Acute Viral Bronchiolitis (Mild, non-hypoxemic)',
    clinicalNotes: 'Chest clear bilaterally, mild subcostal indrawing absent, throat mildly congested, ear drums intact.',
    medications: [
      {
        medicineName: 'Syp. Salbutamol (Ventolin)',
        form: 'Syrup',
        dosage: '2.5 ml',
        frequency: 'TDS (Three times daily)',
        duration: '5 days',
        instructions: 'Give before meals. If child develops jitters, reduce to 2 ml.',
      },
      {
        medicineName: 'Syp. Paracetamol (Calpol 120mg/5ml)',
        form: 'Syrup',
        dosage: '5.0 ml',
        frequency: 'SOS (When Temp > 100°F, min 6 hrs apart)',
        duration: '3 days',
        instructions: 'Shake bottle well before pouring.',
      },
      {
        medicineName: 'Normal Saline Nasal Drops',
        form: 'Drops',
        dosage: '2 drops in each nostril',
        frequency: 'BD to TDS',
        duration: '5 days',
        instructions: 'Instill before feeding and before bedtime to clear nasal blockage.',
      },
    ],
    advice: [
      'Frequent small sips of warm water, soups, or breast milk to stay well hydrated.',
      'Steam inhalation twice daily for 5 minutes in a closed bathroom or gentle steam.',
      'Keep head end of crib/mattress slightly elevated while sleeping.',
      'Emergency red flags: rapid breathing, grunting, refusing fluids, or blue lips.',
    ],
    investigations: ['None required currently. Re-evaluate if fever persists > 48 hours.'],
    followUpDate: 'In 5 days or immediately if breathing difficulty worsens',
    doctorName: 'Dr. Hamid Raza',
    doctorDesignation: 'M.B.B.S. (KE), MD (KE) Pediatrics, Senior Registrar Mayo Hospital Lahore',
    createdAt: '2026-11-02T17:45:00.000Z',
  },
];

const sampleVaccinations: VaccineRecord[] = [
  {
    id: 'vac-1',
    patientId: 'pat-1',
    vaccineName: 'BCG + OPV-0 + Hep-B',
    targetAge: 'At Birth',
    dueDate: '2025-08-14',
    administeredDate: '2025-08-15',
    status: 'completed',
    batchNo: 'BCG-9941',
  },
  {
    id: 'vac-2',
    patientId: 'pat-1',
    vaccineName: 'Pentavalent-1 + OPV-1 + PCV-1 + Rota-1',
    targetAge: '6 Weeks',
    dueDate: '2025-09-25',
    administeredDate: '2025-09-27',
    status: 'completed',
    batchNo: 'PENTA-442',
  },
  {
    id: 'vac-3',
    patientId: 'pat-1',
    vaccineName: 'Pentavalent-2 + OPV-2 + PCV-2 + Rota-2',
    targetAge: '10 Weeks',
    dueDate: '2025-10-23',
    administeredDate: '2025-10-25',
    status: 'completed',
    batchNo: 'PENTA-581',
  },
  {
    id: 'vac-4',
    patientId: 'pat-1',
    vaccineName: 'Pentavalent-3 + OPV-3 + PCV-3 + IPV-1',
    targetAge: '14 Weeks',
    dueDate: '2025-11-20',
    administeredDate: '2025-11-21',
    status: 'completed',
    batchNo: 'IPV-302',
  },
  {
    id: 'vac-5',
    patientId: 'pat-1',
    vaccineName: 'Measles-1 + Typhoid Conjugate Vaccine (TCV)',
    targetAge: '9 Months',
    dueDate: '2026-05-14',
    administeredDate: '2026-05-18',
    status: 'completed',
    batchNo: 'TCV-881',
  },
  {
    id: 'vac-6',
    patientId: 'pat-1',
    vaccineName: 'Measles-2 / MMR-1 Booster',
    targetAge: '15 Months',
    dueDate: '2026-11-14',
    status: 'pending',
    notes: 'Due in next two weeks. Reminder flagged for guardian.',
  },
];

class ClinicDatabase {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DATA_FILE)) {
        const fileContent = fs.readFileSync(DATA_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        // Ensure all required collections exist
        return {
          settings: parsed.settings || defaultSettings,
          appointments: parsed.appointments || sampleAppointments,
          patients: parsed.patients || samplePatients,
          prescriptions: parsed.prescriptions || samplePrescriptions,
          vaccinations: parsed.vaccinations || sampleVaccinations,
        };
      }
    } catch (err) {
      console.error('Error reading clinic_data.json, initializing fresh store:', err);
    }

    // Default seeded state
    const initial: DatabaseSchema = {
      settings: defaultSettings,
      appointments: sampleAppointments,
      patients: samplePatients,
      prescriptions: samplePrescriptions,
      vaccinations: sampleVaccinations,
    };
    this.saveDataDirect(initial);
    return initial;
  }

  private saveDataDirect(data: DatabaseSchema): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write clinic data to file:', err);
    }
  }

  private persist(): void {
    this.saveDataDirect(this.data);
  }

  // --- Settings ---
  public getSettings(): ClinicSettings {
    return this.data.settings;
  }

  public updateSettings(newSettings: Partial<ClinicSettings>): ClinicSettings {
    this.data.settings = {
      ...this.data.settings,
      ...newSettings,
      doctor: {
        ...this.data.settings.doctor,
        ...(newSettings.doctor || {}),
      },
    };
    this.persist();
    return this.data.settings;
  }

  // --- Appointments ---
  public getAppointments(filters?: {
    date?: string;
    clinicId?: string;
    status?: string;
    search?: string;
  }): Appointment[] {
    let list = [...this.data.appointments];

    if (filters?.date) {
      list = list.filter((a) => a.date === filters.date);
    }
    if (filters?.clinicId) {
      list = list.filter((a) => a.clinicLocationId === filters.clinicId);
    }
    if (filters?.status && filters.status !== 'all') {
      list = list.filter((a) => a.status === filters.status);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (a) =>
          a.patientName.toLowerCase().includes(q) ||
          a.guardianPhone.includes(q) ||
          a.bookingReference.toLowerCase().includes(q) ||
          a.guardianName.toLowerCase().includes(q)
      );
    }

    // Sort by date desc, then tokenNumber asc
    return list.sort((a, b) => {
      if (a.date !== b.date) {
        return b.date.localeCompare(a.date);
      }
      return a.tokenNumber - b.tokenNumber;
    });
  }

  public getAppointmentById(id: string): Appointment | undefined {
    return this.data.appointments.find((a) => a.id === id);
  }

  public lookupAppointment(query: string): Appointment[] {
    const q = query.trim().toLowerCase();
    return this.data.appointments.filter(
      (a) =>
        a.bookingReference.toLowerCase() === q ||
        a.guardianPhone.replace(/\D/g, '').endsWith(q.replace(/\D/g, '')) ||
        a.patientName.toLowerCase().includes(q)
    );
  }

  public createAppointment(data: Omit<Appointment, 'id' | 'bookingReference' | 'tokenNumber' | 'createdAt'>): Appointment {
    // Generate next token number for this date and location
    const sameDayAppointments = this.data.appointments.filter(
      (a) => a.date === data.date && a.clinicLocationId === data.clinicLocationId
    );
    const maxToken = sameDayAppointments.reduce((max, cur) => Math.max(max, cur.tokenNumber || 0), 0);
    const tokenNumber = maxToken + 1;

    // Generate readable booking reference e.g. HR-4921
    const randNum = Math.floor(1000 + Math.random() * 9000);
    const bookingReference = `HR-${randNum}`;

    const newAppointment: Appointment = {
      ...data,
      id: `apt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      bookingReference,
      tokenNumber,
      createdAt: new Date().toISOString(),
    };

    this.data.appointments.push(newAppointment);

    // Auto-link or create patient record if not exists
    let existingPatient = this.data.patients.find(
      (p) =>
        p.guardianPhone === data.guardianPhone &&
        p.childName.toLowerCase() === data.patientName.toLowerCase()
    );

    if (!existingPatient) {
      const mrnNum = 1000 + this.data.patients.length + 1;
      const newPatient: Patient = {
        id: `pat-${Date.now()}`,
        mrn: `MR-${new Date().getFullYear()}-${mrnNum}`,
        childName: data.patientName,
        dob: `${new Date().getFullYear() - data.patientAgeYears}-${String(
          Math.max(1, 12 - data.patientAgeMonths)
        ).padStart(2, '0')}-01`,
        gender: data.patientGender,
        bloodGroup: 'Unknown',
        allergies: [],
        guardianName: data.guardianName,
        guardianPhone: data.guardianPhone,
        address: 'Lahore',
        historyNotes: `First booked via online portal: ${data.reasonForVisit}`,
        createdAt: new Date().toISOString(),
      };
      this.data.patients.push(newPatient);
      newAppointment.patientId = newPatient.id;
    } else {
      newAppointment.patientId = existingPatient.id;
    }

    this.persist();
    return newAppointment;
  }

  public updateAppointment(id: string, updates: Partial<Appointment>): Appointment | null {
    const idx = this.data.appointments.findIndex((a) => a.id === id);
    if (idx === -1) return null;
    this.data.appointments[idx] = {
      ...this.data.appointments[idx],
      ...updates,
    };
    this.persist();
    return this.data.appointments[idx];
  }

  public deleteAppointment(id: string): boolean {
    const initialLen = this.data.appointments.length;
    this.data.appointments = this.data.appointments.filter((a) => a.id !== id);
    const deleted = this.data.appointments.length < initialLen;
    if (deleted) this.persist();
    return deleted;
  }

  // --- Patients ---
  public getPatients(search?: string): Patient[] {
    if (!search) return this.data.patients;
    const q = search.toLowerCase();
    return this.data.patients.filter(
      (p) =>
        p.childName.toLowerCase().includes(q) ||
        p.guardianName.toLowerCase().includes(q) ||
        p.guardianPhone.includes(q) ||
        p.mrn.toLowerCase().includes(q)
    );
  }

  public getPatientById(id: string): Patient | undefined {
    return this.data.patients.find((p) => p.id === id);
  }

  public createPatient(data: Omit<Patient, 'id' | 'mrn' | 'createdAt'>): Patient {
    const mrnNum = 1000 + this.data.patients.length + 1;
    const newPatient: Patient = {
      ...data,
      id: `pat-${Date.now()}`,
      mrn: `MR-${new Date().getFullYear()}-${mrnNum}`,
      createdAt: new Date().toISOString(),
    };
    this.data.patients.push(newPatient);
    this.persist();
    return newPatient;
  }

  public updatePatient(id: string, updates: Partial<Patient>): Patient | null {
    const idx = this.data.patients.findIndex((p) => p.id === id);
    if (idx === -1) return null;
    this.data.patients[idx] = {
      ...this.data.patients[idx],
      ...updates,
    };
    this.persist();
    return this.data.patients[idx];
  }

  // --- Prescriptions ---
  public getPrescriptions(patientId?: string): Prescription[] {
    if (patientId) {
      return this.data.prescriptions.filter((p) => p.patientId === patientId);
    }
    return [...this.data.prescriptions].reverse();
  }

  public getPrescriptionById(id: string): Prescription | undefined {
    return this.data.prescriptions.find((p) => p.id === id);
  }

  public createPrescription(data: Omit<Prescription, 'id' | 'prescriptionNumber' | 'createdAt'>): Prescription {
    const count = this.data.prescriptions.length + 1;
    const yr = new Date().getFullYear().toString().slice(-2);
    const prescriptionNumber = `RX-${yr}-${String(count).padStart(4, '0')}`;

    const newRx: Prescription = {
      ...data,
      id: `rx-${Date.now()}`,
      prescriptionNumber,
      createdAt: new Date().toISOString(),
    };
    this.data.prescriptions.push(newRx);

    // If an appointment was linked, automatically mark it completed
    if (data.appointmentId) {
      this.updateAppointment(data.appointmentId, {
        status: 'completed',
        paymentStatus: 'paid',
      });
    }

    this.persist();
    return newRx;
  }

  // --- Vaccinations ---
  public getVaccinations(patientId: string): VaccineRecord[] {
    return this.data.vaccinations.filter((v) => v.patientId === patientId);
  }

  public updateVaccineRecord(id: string, updates: Partial<VaccineRecord>): VaccineRecord | null {
    const idx = this.data.vaccinations.findIndex((v) => v.id === id);
    if (idx === -1) return null;
    this.data.vaccinations[idx] = {
      ...this.data.vaccinations[idx],
      ...updates,
    };
    this.persist();
    return this.data.vaccinations[idx];
  }

  public addVaccineRecord(data: Omit<VaccineRecord, 'id'>): VaccineRecord {
    const newRecord: VaccineRecord = {
      ...data,
      id: `vac-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    };
    this.data.vaccinations.push(newRecord);
    this.persist();
    return newRecord;
  }

  // --- CRM Analytics / Stats ---
  public getStats() {
    const today = new Date().toISOString().split('T')[0];
    const todayApts = this.data.appointments.filter((a) => a.date === today);

    const inQueue = todayApts.filter((a) => a.status === 'in-queue' || a.status === 'confirmed').length;
    const completed = todayApts.filter((a) => a.status === 'completed').length;
    const inConsultation = todayApts.find((a) => a.status === 'in-consultation');
    const totalTodayRevenue = todayApts
      .filter((a) => a.paymentStatus === 'paid')
      .reduce((sum, a) => sum + (a.fee || 0), 0);

    return {
      totalPatients: this.data.patients.length,
      todayAppointments: todayApts.length,
      inQueueCount: inQueue,
      completedTodayCount: completed,
      currentConsultation: inConsultation || null,
      todayRevenue: totalTodayRevenue,
      totalPrescriptions: this.data.prescriptions.length,
    };
  }
}

export const clinicDb = new ClinicDatabase();
