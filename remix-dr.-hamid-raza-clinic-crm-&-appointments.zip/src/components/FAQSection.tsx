import React, { useState } from 'react';
import {
  HelpCircle,
  ChevronDown,
  Phone,
  MessageCircle,
  FileQuestion,
  Calendar,
} from 'lucide-react';
import { ClinicSettings, FAQItem } from '../types/clinic';

interface FAQSectionProps {
  settings: ClinicSettings;
  onOpenBooking: () => void;
}

export const FAQSection: React.FC<FAQSectionProps> = ({ settings, onOpenBooking }) => {
  const [openId, setOpenId] = useState<string>(settings.faqs[0]?.id || '');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'General', 'Appointments', 'Vaccination', 'Newborn Care'];

  const filteredFaqs =
    selectedCategory === 'All'
      ? settings.faqs
      : settings.faqs.filter((f) => f.category === selectedCategory);

  const toggleFAQ = (id: string) => {
    setOpenId(openId === id ? '' : id);
  };

  return (
    <section id="faqs" className="py-20 bg-slate-50/70 border-t border-slate-200/70">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-teal-100/80 text-teal-800 border border-teal-200">
            <HelpCircle className="w-4 h-4 text-teal-600" />
            <span>Parent Guidelines &amp; FAQs</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-base text-slate-600">
            Helpful answers to common questions about clinic appointments, newborn care, and doctor visits.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* FAQs Accordion */}
        <div className="space-y-3">
          {filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden shadow-2xs transition-all"
              >
                <button
                  type="button"
                  onClick={() => toggleFAQ(faq.id)}
                  className="w-full px-6 py-4.5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50/70 transition-colors"
                >
                  <span className="font-bold text-sm sm:text-base text-slate-900">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-teal-600' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-6 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions */}
        <div className="mt-12 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-bold text-base text-slate-900">Have a specific question about your child?</h4>
            <p className="text-xs text-slate-500">
              Our clinic receptionist is available during clinic hours for appointment assistance.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <a
              href={`tel:${settings.doctor.phone}`}
              className="px-4 py-2.5 rounded-xl font-bold text-xs text-slate-700 bg-slate-100 hover:bg-slate-200 flex items-center gap-2"
            >
              <Phone className="w-4 h-4 text-teal-600" />
              Call Desk
            </a>
            <button
              onClick={onOpenBooking}
              className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-teal-600 hover:bg-teal-700 shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              Book Appointment
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
