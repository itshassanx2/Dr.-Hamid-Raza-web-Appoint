import React from 'react';
import {
  Building2,
  Clock,
  Calendar,
  Phone,
  MapPin,
  CreditCard,
  Video,
  Hospital,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { ClinicLocation, ClinicSettings } from '../types/clinic';

interface ClinicLocationsSectionProps {
  settings: ClinicSettings;
  onSelectClinicForBooking: (clinicId: string) => void;
}

export const ClinicLocationsSection: React.FC<ClinicLocationsSectionProps> = ({
  settings,
  onSelectClinicForBooking,
}) => {
  return (
    <section id="locations" className="py-20 bg-white border-t border-slate-200/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-teal-50 text-teal-700 border border-teal-200">
            <MapPin className="w-4 h-4 text-teal-600" />
            <span>Consultation Schedules &amp; Locations</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Clinic Centers &amp; Timings
          </h2>
          <p className="text-base sm:text-lg text-slate-600">
            Dr. Hamid Raza examines patients across institutional hospital OPD, private evening clinic, and online pediatric tele-consultation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {settings.locations.map((loc) => {
            const isTelehealth = loc.type === 'telehealth';
            const isHospital = loc.type === 'hospital';

            return (
              <div
                key={loc.id}
                className="bg-white rounded-3xl p-7 border border-slate-200/90 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between relative overflow-hidden group"
              >
                {/* Top accent badge */}
                <div
                  className={`absolute top-0 left-0 right-0 h-1.5 ${
                    isHospital
                      ? 'bg-blue-600'
                      : isTelehealth
                      ? 'bg-purple-600'
                      : 'bg-teal-600'
                  }`}
                />

                <div className="space-y-5">
                  <div className="flex items-center justify-between">
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                        isHospital
                          ? 'bg-blue-50 text-blue-700'
                          : isTelehealth
                          ? 'bg-purple-50 text-purple-700'
                          : 'bg-teal-50 text-teal-700'
                      }`}
                    >
                      {isHospital ? (
                        <Hospital className="w-6 h-6" />
                      ) : isTelehealth ? (
                        <Video className="w-6 h-6" />
                      ) : (
                        <Building2 className="w-6 h-6" />
                      )}
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold ${
                        isHospital
                          ? 'bg-blue-50 text-blue-800 border border-blue-200'
                          : isTelehealth
                          ? 'bg-purple-50 text-purple-800 border border-purple-200'
                          : 'bg-teal-50 text-teal-800 border border-teal-200'
                      }`}
                    >
                      {loc.city}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xl font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                      {loc.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">{loc.tagline}</p>
                  </div>

                  {/* Schedule Details */}
                  <div className="space-y-3 pt-3 border-t border-slate-100 text-xs">
                    <div className="flex items-start gap-2.5">
                      <Calendar className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-800">Days</div>
                        <div className="text-slate-600">{loc.days}</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Clock className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-800">Consultation Timings</div>
                        <div className="text-slate-600 font-semibold text-teal-800">
                          {loc.timings}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <MapPin className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-800">Address</div>
                        <div className="text-slate-600 leading-relaxed">{loc.address}</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <CreditCard className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-slate-800">Consultation Fee</div>
                        <div className="text-slate-900 font-bold">
                          {loc.fee === 0 ? (
                            <span className="text-emerald-700">Hospital Free OPD / Subsidized</span>
                          ) : (
                            <span>Rs. {loc.fee.toLocaleString()} PKR</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {loc.phone && (
                      <div className="flex items-start gap-2.5">
                        <Phone className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                        <div>
                          <div className="font-bold text-slate-800">Desk Phone</div>
                          <div className="text-slate-600">{loc.phone}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100">
                  <button
                    onClick={() => onSelectClinicForBooking(loc.id)}
                    className="w-full py-3 px-4 rounded-xl font-bold text-xs text-white bg-slate-900 group-hover:bg-teal-700 shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                  >
                    <span>Book at this Location</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Note on configuration */}
        <div className="mt-10 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
          Clinic timings, consultation fees, and session slots are updated directly by clinic administration. For corporate or institutional inquiries, please contact the front desk.
        </div>
      </div>
    </section>
  );
};
