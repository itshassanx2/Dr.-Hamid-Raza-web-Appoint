import React from 'react';
import {
  Calendar,
  Clock,
  Phone,
  Shield,
  Stethoscope,
  Search,
  UserCheck,
  Building2,
  ChevronRight,
  Menu,
  X,
} from 'lucide-react';
import { ClinicSettings } from '../types/clinic';

interface NavbarProps {
  settings: ClinicSettings;
  activeSection: string;
  onNavigate: (section: string) => void;
  onOpenBooking: () => void;
  onOpenTracker: () => void;
  onOpenAdmin: () => void;
  isAdminLoggedIn: boolean;
  currentUser?: { name: string; role: string } | null;
}

export const Navbar: React.FC<NavbarProps> = ({
  settings,
  activeSection,
  onNavigate,
  onOpenBooking,
  onOpenTracker,
  onOpenAdmin,
  isAdminLoggedIn,
  currentUser,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'profile', label: 'Doctor Profile' },
    { id: 'services', label: 'Specializations' },
    { id: 'locations', label: 'Clinics & Timings' },
    { id: 'faqs', label: 'FAQs' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-teal-100 shadow-xs">
      {/* Top Clinical Utility Bar */}
      <div className="bg-gradient-to-r from-teal-800 via-teal-900 to-slate-900 text-teal-50 text-xs py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="inline-flex items-center gap-1.5 font-medium text-teal-200">
              <Shield className="w-3.5 h-3.5 text-teal-400" />
              {settings.doctor.pmdcNumber}
            </span>
            <span className="hidden md:inline text-teal-400/60">•</span>
            <span className="hidden md:inline-flex items-center gap-1.5 text-teal-100">
              <Building2 className="w-3.5 h-3.5 text-teal-300" />
              {settings.doctor.designation}
            </span>
            <span className="hidden lg:inline text-teal-400/60">•</span>
            <span className="hidden lg:inline-flex items-center gap-1.5 text-amber-300">
              <Phone className="w-3.5 h-3.5" />
              Emergency: {settings.emergencyContact}
            </span>
          </div>

          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={onOpenTracker}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-teal-700/60 hover:bg-teal-700 text-white transition-colors cursor-pointer"
            >
              <Search className="w-3.5 h-3.5 text-teal-300" />
              Track Booking
            </button>
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold bg-white/10 hover:bg-white/20 text-teal-100 border border-teal-600/40 transition-colors cursor-pointer"
            >
              <UserCheck className="w-3.5 h-3.5 text-teal-300" />
              {isAdminLoggedIn ? (
                <span>CRM Dashboard ({currentUser?.role === 'doctor' ? 'Dr. Hamid' : 'Staff'})</span>
              ) : (
                <span>Doctor / Staff Portal</span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand & Doctor Name */}
          <div
            onClick={() => onNavigate('home')}
            className="flex items-center gap-3.5 cursor-pointer group select-none"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-teal-600 to-teal-800 flex items-center justify-center text-white shadow-md shadow-teal-700/20 group-hover:scale-105 transition-transform">
              <Stethoscope className="w-6 h-6 text-teal-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-slate-900 group-hover:text-teal-700 transition-colors">
                  {settings.doctor.name}
                </span>
                <span className="hidden sm:inline-flex px-2 py-0.5 rounded-full text-[11px] font-bold bg-teal-50 text-teal-700 border border-teal-200">
                  KE Alumnus
                </span>
              </div>
              <p className="text-xs font-semibold text-teal-700 tracking-wide">
                {settings.doctor.specialization}
              </p>
              <p className="text-[11px] text-slate-500 line-clamp-1">
                {settings.doctor.qualifications} • Mayo Hospital Lahore
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`text-sm font-semibold transition-colors cursor-pointer relative py-1 ${
                  activeSection === link.id
                    ? 'text-teal-700 font-bold'
                    : 'text-slate-600 hover:text-teal-600'
                }`}
              >
                {link.label}
                {activeSection === link.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal-600 rounded-full" />
                )}
              </button>
            ))}
          </nav>

          {/* Actions */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={onOpenTracker}
              className="px-3.5 py-2 text-xs font-bold text-slate-700 hover:text-teal-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Check Queue / Token
            </button>
            <button
              onClick={onOpenBooking}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 shadow-md shadow-teal-600/25 hover:shadow-lg transition-all cursor-pointer active:scale-95"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>

          {/* Mobile hamburger */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={onOpenBooking}
              className="sm:hidden px-3 py-1.5 text-xs font-bold bg-teal-600 text-white rounded-lg"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-teal-700 rounded-lg"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-xl">
          <div className="grid grid-cols-1 gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold text-left ${
                  activeSection === link.id
                    ? 'bg-teal-50 text-teal-700 font-bold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>{link.label}</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenBooking();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-white bg-teal-600 hover:bg-teal-700 shadow-sm"
            >
              <Calendar className="w-4 h-4" />
              Book Pediatric Appointment
            </button>
            <button
              onClick={() => {
                onOpenTracker();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200"
            >
              <Search className="w-4 h-4 text-slate-500" />
              Track Appointment / Check Token
            </button>
            <button
              onClick={() => {
                onOpenAdmin();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs font-semibold text-teal-700 hover:underline"
            >
              <UserCheck className="w-3.5 h-3.5" />
              Doctor & Receptionist Admin Login
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
