import React from 'react';
import {
  Stethoscope,
  Phone,
  Mail,
  MapPin,
  Shield,
  Building2,
  Calendar,
  Lock,
  Heart,
} from 'lucide-react';
import { ClinicSettings } from '../types/clinic';

interface FooterProps {
  settings: ClinicSettings;
  onNavigate: (section: string) => void;
  onOpenBooking: () => void;
  onOpenAdmin: () => void;
  onOpenTracker: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  onNavigate,
  onOpenBooking,
  onOpenAdmin,
  onOpenTracker,
}) => {
  return (
    <footer className="bg-slate-900 text-slate-300 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Col 1: Doctor Profile Summary */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white">
                <Stethoscope className="w-5 h-5 text-teal-100" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">
                  {settings.doctor.name}
                </h3>
                <p className="text-xs text-teal-400 font-semibold">
                  {settings.doctor.specialization}
                </p>
              </div>
            </div>

            <p className="text-slate-400 leading-relaxed text-xs">
              {settings.doctor.qualifications} from King Edward Medical University. Currently serving as {settings.doctor.designation}. Dedicated to the highest standards of evidence-based pediatric medicine and neonatal intensive care.
            </p>

            <div className="pt-2 space-y-2 text-slate-300">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{settings.doctor.pmdcNumber}</span>
              </div>
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-teal-400 shrink-0" />
                <span>{settings.doctor.hospitalAffiliation}</span>
              </div>
            </div>
          </div>

          {/* Col 2: Clinic Locations Quick Links */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Consultation Centers
            </h4>
            <div className="space-y-3 text-xs">
              {settings.locations.map((loc) => (
                <div key={loc.id} className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-800">
                  <div className="font-bold text-white">{loc.name}</div>
                  <div className="text-teal-400 text-[11px] font-semibold">{loc.timings} ({loc.days})</div>
                  <div className="text-slate-400 text-[11px] line-clamp-1">{loc.address}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Col 3: Quick Navigation & Portal */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Patient Services
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={onOpenBooking}
                  className="hover:text-teal-400 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Calendar className="w-3.5 h-3.5 text-teal-400" />
                  Book an Appointment
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenTracker}
                  className="hover:text-teal-400 transition-colors cursor-pointer"
                >
                  Track Existing Booking &amp; Queue
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('services')}
                  className="hover:text-teal-400 transition-colors cursor-pointer"
                >
                  Pediatric Care &amp; Specializations
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('locations')}
                  className="hover:text-teal-400 transition-colors cursor-pointer"
                >
                  Clinic Hours &amp; Locations
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('faqs')}
                  className="hover:text-teal-400 transition-colors cursor-pointer"
                >
                  Frequently Asked Questions
                </button>
              </li>
              <li className="pt-2 border-t border-slate-800">
                <button
                  onClick={onOpenAdmin}
                  className="inline-flex items-center gap-1.5 text-teal-400 hover:text-teal-300 font-bold transition-colors cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  Doctor &amp; Staff CRM Login
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright & emergency warning */}
        <div className="pt-10 mt-10 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} Dr. Hamid Raza — Pediatric &amp; Neonatal Clinic. All rights reserved.
          </div>
          <div className="flex items-center gap-1 text-slate-400">
            <span>Clinical portal engineered for optimal pediatric healthcare</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
