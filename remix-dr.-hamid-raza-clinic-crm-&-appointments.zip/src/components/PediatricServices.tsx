import React from 'react';
import {
  Baby,
  Syringe,
  Wind,
  LineChart,
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  Calendar,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';

interface PediatricServicesProps {
  onOpenBooking: (serviceName?: string) => void;
}

export const PediatricServices: React.FC<PediatricServicesProps> = ({ onOpenBooking }) => {
  const services = [
    {
      id: 'neonatology',
      title: 'Neonatal & Newborn Care',
      subtitle: 'Critical care for infants from birth to 28 days',
      icon: Baby,
      badge: 'Specialist Domain',
      color: 'teal',
      points: [
        'Neonatal hyperbilirubinemia (jaundice) assessment & phototherapy guidance',
        'Preterm infant follow-up & high-risk infant discharge review',
        'Umbilical cord care, neonatal feeding issues, and infant colic',
        'Birth asphyxia and congenital anomaly screenings',
      ],
    },
    {
      id: 'vaccination',
      title: 'Immunization & Vaccinations',
      subtitle: 'EPI schedule and WHO-recommended child vaccines',
      icon: Syringe,
      badge: 'Preventive Health',
      color: 'emerald',
      points: [
        'Routine EPI Schedule (BCG, Polio, Pentavalent, PCV, Rota, Measles)',
        'Recommended optional boosters (Typhoid TCV, Hepatitis A, Varicella, MMR)',
        'Strict cold-chain monitored pediatric storage standards',
        'Vaccine catch-up schedules for missed infant doses',
      ],
    },
    {
      id: 'asthma',
      title: 'Pediatric Asthma & Allergies',
      subtitle: 'Comprehensive respiratory care for wheezing & chronic cough',
      icon: Wind,
      badge: 'Pulmonology',
      color: 'cyan',
      points: [
        'Early childhood wheezing vs. bronchial asthma differentiation',
        'Metered dose inhaler (MDI) and spacer technique education',
        'Acute bronchiolitis & viral-triggered cough management',
        'Allergic rhinitis and seasonal environmental allergy control',
      ],
    },
    {
      id: 'growth',
      title: 'Growth, Nutrition & Milestones',
      subtitle: 'Ensuring your child hits every developmental benchmark',
      icon: LineChart,
      badge: 'Developmental',
      color: 'amber',
      points: [
        'WHO standardized growth charting (weight, height, head circumference)',
        'Failure to thrive, weight faltering, and poor appetite evaluations',
        'Infant weaning diets and age-appropriate solids introduction',
        'Micronutrient deficiencies (Iron deficiency anemia, Rickets, Vitamin D)',
      ],
    },
    {
      id: 'infections',
      title: 'Childhood Infectious Diseases',
      subtitle: 'Rational, evidence-based antimicrobial treatment',
      icon: ShieldAlert,
      badge: 'Acute Care',
      color: 'blue',
      points: [
        'Prolonged fever workups (Typhoid fever, Dengue, Malaria)',
        'Pediatric pneumonia and acute respiratory tract infections',
        'Acute gastroenteritis, vomiting, diarrhea, and ORS rehydration',
        'Careful stewardship against unwarranted antibiotic prescribing',
      ],
    },
    {
      id: 'general',
      title: 'General Pediatric Checkups',
      subtitle: 'Routine wellness assessments and parent counseling',
      icon: Sparkles,
      badge: 'Primary Care',
      color: 'indigo',
      points: [
        'Comprehensive physical examination for school and preschool',
        'Sleep hygiene and toddler behavioral counseling',
        'Urinary tract infections (UTI) and bedwetting advice',
        'Direct hospital admission pathways for urgent Mayo Hospital cases',
      ],
    },
  ];

  return (
    <section id="services" className="py-20 bg-slate-50/70 border-t border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-teal-100/80 text-teal-800 border border-teal-200">
            <span>Comprehensive Clinical Services</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Specialized Pediatric &amp; Neonatal Care
          </h2>
          <p className="text-base sm:text-lg text-slate-600">
            Every consultation is conducted with thorough clinical examination, clear communication, and personalized guidance for parents.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((svc) => {
            const Icon = svc.icon;
            return (
              <div
                key={svc.id}
                className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group hover:-translate-y-1"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center text-teal-700 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                      {svc.badge}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                      {svc.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">{svc.subtitle}</p>
                  </div>

                  <ul className="space-y-2 pt-2 border-t border-slate-100">
                    {svc.points.map((pt, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-600 leading-relaxed">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6 mt-4 border-t border-slate-100">
                  <button
                    onClick={() => onOpenBooking(svc.title)}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-teal-700 bg-teal-50 hover:bg-teal-600 hover:text-white transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    Book for {svc.title.split(' ')[0]}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pediatric Emergency Banner */}
        <div className="mt-12 bg-amber-50 rounded-2xl p-6 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 text-sm">
                Pediatric Warning Signs &amp; Emergency Protocol
              </h4>
              <p className="text-xs text-slate-600">
                If your child exhibits severe grunting, blue discoloration, seizure fits, or extreme lethargy, do not wait for an appointment. Proceed immediately to Mayo Hospital 24/7 Pediatric Emergency.
              </p>
            </div>
          </div>
          <button
            onClick={() => onOpenBooking()}
            className="whitespace-nowrap px-5 py-2.5 rounded-xl text-xs font-bold text-slate-900 bg-amber-300 hover:bg-amber-400 shadow-xs cursor-pointer"
          >
            Schedule Regular Consultation
          </button>
        </div>
      </div>
    </section>
  );
};
