import React, { useState } from 'react';
import {
  Users,
  Clock,
  CheckCircle2,
  AlertCircle,
  Activity,
  Phone,
  Baby,
  Plus,
  Play,
  FileText,
  DollarSign,
  ChevronRight,
  ArrowRight,
  UserCheck,
} from 'lucide-react';
import { Appointment, ClinicStats, ClinicLocation } from '../../types/clinic';

interface LiveQueueDashboardProps {
  stats: ClinicStats | null;
  todayAppointments: Appointment[];
  locations: ClinicLocation[];
  onUpdateStatus: (id: string, status: Appointment['status']) => Promise<void>;
  onTogglePayment: (id: string, current: 'paid' | 'pending' | 'waived') => Promise<void>;
  onOpenWritePrescription: (appointment: Appointment) => void;
  onOpenWalkInModal: () => void;
  onViewPatientDetails: (patientId?: string, fallbackApt?: Appointment) => void;
}

export const LiveQueueDashboard: React.FC<LiveQueueDashboardProps> = ({
  stats,
  todayAppointments,
  locations,
  onUpdateStatus,
  onTogglePayment,
  onOpenWritePrescription,
  onOpenWalkInModal,
  onViewPatientDetails,
}) => {
  const [callingNext, setCallingNext] = useState(false);

  // Identify current in-consultation appointment
  const currentInConsultation = todayAppointments.find((a) => a.status === 'in-consultation');

  // Identify waiting queue (status: 'in-queue' or 'confirmed') sorted by token
  const waitingPatients = todayAppointments
    .filter((a) => a.status === 'in-queue' || a.status === 'confirmed')
    .sort((a, b) => a.tokenNumber - b.tokenNumber);

  const completedPatients = todayAppointments.filter((a) => a.status === 'completed');

  const handleCallNext = async () => {
    if (waitingPatients.length === 0) return;
    setCallingNext(true);
    try {
      // If there was someone in consultation, mark them completed or let doctor finish
      const nextInLine = waitingPatients[0];
      await onUpdateStatus(nextInLine.id, 'in-consultation');
    } finally {
      setCallingNext(false);
    }
  };

  const getLocationName = (locId: string) => {
    return locations.find((l) => l.id === locId)?.name || 'Clinic';
  };

  return (
    <div className="space-y-6">
      {/* Top Real-Time KPI Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Today's Total</span>
            <Users className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            {todayAppointments.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Booked slots</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-blue-700 text-xs font-semibold">
            <span>Waiting in Queue</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-blue-700 mt-2">
            {waitingPatients.length}
          </div>
          <div className="text-[11px] text-blue-600/70 mt-0.5">Next in line</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-2xs bg-amber-50/40">
          <div className="flex items-center justify-between text-amber-800 text-xs font-semibold">
            <span>In Consultation</span>
            <Activity className="w-4 h-4 text-amber-600 animate-pulse" />
          </div>
          <div className="text-2xl font-black text-amber-800 mt-2">
            {currentInConsultation ? `#${currentInConsultation.tokenNumber}` : 'None'}
          </div>
          <div className="text-[11px] text-amber-700 mt-0.5 line-clamp-1">
            {currentInConsultation ? currentInConsultation.patientName : 'Doctor Ready'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-emerald-700 text-xs font-semibold">
            <span>Completed Today</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-2">
            {completedPatients.length}
          </div>
          <div className="text-[11px] text-emerald-600/70 mt-0.5">Prescriptions issued</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Today's Fees</span>
            <DollarSign className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            Rs. {stats?.todayRevenue.toLocaleString() || '0'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Collected at desk</div>
        </div>
      </div>

      {/* Live Queue Controller: Active Consultation & Call Next */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Active Consultation Spotlight */}
        <div className="lg:col-span-7 bg-gradient-to-br from-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg flex flex-col justify-between relative overflow-hidden">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-400 text-slate-950">
                <span className="w-2 h-2 rounded-full bg-slate-950 animate-ping" />
                ACTIVE DOCTOR ROOM SESSION
              </span>
              <span className="text-xs text-teal-200">
                Dr. Hamid Raza's Desk
              </span>
            </div>

            {currentInConsultation ? (
              <div className="space-y-4 pt-2">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-3xl font-black text-white">
                      {currentInConsultation.patientName}
                    </div>
                    <div className="text-sm text-teal-300 font-semibold mt-0.5">
                      {currentInConsultation.patientAgeYears} Years {currentInConsultation.patientAgeMonths} Months • {currentInConsultation.patientGender}
                    </div>
                    <div className="text-xs text-slate-300 mt-1 flex items-center gap-2">
                      <span>Guardian: {currentInConsultation.guardianName} ({currentInConsultation.guardianRelation})</span>
                      <span>•</span>
                      <span>{currentInConsultation.guardianPhone}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-teal-300 block font-bold">TOKEN</span>
                    <span className="text-4xl font-black text-amber-300">
                      #{String(currentInConsultation.tokenNumber).padStart(2, '0')}
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5 font-mono">
                      {currentInConsultation.bookingReference}
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-white/10 border border-white/15 text-xs text-teal-100 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-teal-300 tracking-wider block">
                    Chief Complaint / Reason for Consultation:
                  </span>
                  <p className="font-medium text-white">{currentInConsultation.reasonForVisit}</p>
                </div>
              </div>
            ) : (
              <div className="py-10 text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center mx-auto text-teal-300">
                  <UserCheck className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-white">No patient currently in consultation</h4>
                <p className="text-xs text-slate-400">
                  {waitingPatients.length > 0
                    ? `${waitingPatients.length} patient(s) waiting in queue. Call the next token below.`
                    : 'All scheduled patients have been attended to.'}
                </p>
              </div>
            )}
          </div>

          {/* Action Buttons for active patient */}
          <div className="pt-6 mt-4 border-t border-white/10 flex flex-wrap items-center gap-3">
            {currentInConsultation ? (
              <>
                <button
                  onClick={() => onOpenWritePrescription(currentInConsultation)}
                  className="flex-1 py-3 px-4 rounded-xl font-bold text-xs text-slate-900 bg-amber-300 hover:bg-amber-200 shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <FileText className="w-4 h-4 text-slate-900" />
                  Write Prescription &amp; Complete
                </button>
                <button
                  onClick={() => onUpdateStatus(currentInConsultation.id, 'completed')}
                  className="py-3 px-4 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-700 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Mark Completed
                </button>
                <button
                  onClick={() => onViewPatientDetails(currentInConsultation.patientId, currentInConsultation)}
                  className="py-3 px-4 rounded-xl font-bold text-xs text-teal-100 bg-white/10 hover:bg-white/20 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  View Medical History
                </button>
              </>
            ) : (
              <button
                disabled={waitingPatients.length === 0 || callingNext}
                onClick={handleCallNext}
                className="w-full py-3.5 px-6 rounded-xl font-bold text-sm text-slate-900 bg-teal-300 hover:bg-teal-200 disabled:opacity-40 disabled:cursor-not-allowed shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Play className="w-4 h-4 fill-slate-900 text-slate-900" />
                {waitingPatients.length > 0
                  ? `Call Next Patient: #${waitingPatients[0]?.tokenNumber} ${waitingPatients[0]?.patientName}`
                  : 'No Patients in Queue'}
              </button>
            )}
          </div>
        </div>

        {/* Next in Line Call Board & Walk-In Trigger */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold text-base text-slate-900">Next In Waiting Line</h4>
                <p className="text-xs text-slate-500">{waitingPatients.length} children waiting</p>
              </div>
              <button
                onClick={onOpenWalkInModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Walk-in
              </button>
            </div>

            {waitingPatients.length > 0 ? (
              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {waitingPatients.slice(0, 4).map((patient, idx) => (
                  <div
                    key={patient.id}
                    className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                      idx === 0
                        ? 'border-blue-300 bg-blue-50/50'
                        : 'border-slate-200/80 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${
                          idx === 0
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        #{patient.tokenNumber}
                      </div>
                      <div>
                        <div className="font-bold text-xs text-slate-900 line-clamp-1">
                          {patient.patientName}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {patient.patientAgeYears}y {patient.patientAgeMonths}m • {patient.timeSlot}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => onUpdateStatus(patient.id, 'in-consultation')}
                        className="px-2.5 py-1.5 rounded-lg font-bold text-[11px] bg-teal-600 text-white hover:bg-teal-700 cursor-pointer flex items-center gap-1"
                      >
                        Call In
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-400 rounded-2xl bg-slate-50">
                Queue is clear. New appointments will appear here as they are booked.
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Average consultation: 15-20 min</span>
            <span className="font-bold text-teal-700">Live Auto-Sync Active</span>
          </div>
        </div>
      </div>

      {/* Today's Full Queue Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-base text-slate-900">Today's Queue &amp; Patient Registry</h4>
            <p className="text-xs text-slate-500">Manage arrivals, tokens, payment, and consultation status</p>
          </div>
          <button
            onClick={onOpenWalkInModal}
            className="px-4 py-2 rounded-xl font-bold text-xs text-white bg-teal-700 hover:bg-teal-800 shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            New Walk-in Patient
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold text-[10px] border-b border-slate-100">
              <tr>
                <th className="px-5 py-3">Token &amp; Ref</th>
                <th className="px-5 py-3">Child Patient</th>
                <th className="px-5 py-3">Guardian</th>
                <th className="px-5 py-3">Slot &amp; Clinic</th>
                <th className="px-5 py-3">Reason for Visit</th>
                <th className="px-5 py-3">Fee Status</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {todayAppointments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-8 text-center text-slate-400">
                    No appointments scheduled for today.
                  </td>
                </tr>
              ) : (
                todayAppointments.map((apt) => (
                  <tr key={apt.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className="w-8 h-8 rounded-lg bg-teal-50 text-teal-800 font-black text-xs flex items-center justify-center border border-teal-200">
                          #{String(apt.tokenNumber).padStart(2, '0')}
                        </span>
                        <div>
                          <span className="font-mono text-slate-600 font-bold block">{apt.bookingReference}</span>
                        </div>
                      </div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div
                        onClick={() => onViewPatientDetails(apt.patientId, apt)}
                        className="font-bold text-slate-900 hover:text-teal-700 cursor-pointer"
                      >
                        {apt.patientName}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {apt.patientAgeYears}y {apt.patientAgeMonths}m • {apt.patientGender}
                      </div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div className="font-semibold text-slate-800">{apt.guardianName}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {apt.guardianPhone}
                      </div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div className="font-bold text-slate-800">{apt.timeSlot}</div>
                      <div className="text-[11px] text-slate-500 line-clamp-1">
                        {getLocationName(apt.clinicLocationId)}
                      </div>
                    </td>

                    <td className="px-5 py-3.5 max-w-xs">
                      <p className="text-slate-600 line-clamp-1">{apt.reasonForVisit}</p>
                    </td>

                    <td className="px-5 py-3.5">
                      <button
                        onClick={() => onTogglePayment(apt.id, apt.paymentStatus)}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold cursor-pointer transition-colors ${
                          apt.paymentStatus === 'paid'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : apt.paymentStatus === 'waived'
                            ? 'bg-slate-100 text-slate-600'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {apt.paymentStatus === 'paid'
                          ? `Paid (Rs. ${apt.fee})`
                          : apt.paymentStatus === 'waived'
                          ? 'Waived (Free)'
                          : `Pending (Rs. ${apt.fee})`}
                      </button>
                    </td>

                    <td className="px-5 py-3.5">
                      <select
                        value={apt.status}
                        onChange={(e) => onUpdateStatus(apt.id, e.target.value as any)}
                        className={`text-xs font-bold px-2 py-1 rounded-lg border focus:outline-none cursor-pointer ${
                          apt.status === 'in-consultation'
                            ? 'bg-amber-50 text-amber-800 border-amber-300'
                            : apt.status === 'in-queue'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : apt.status === 'completed'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : apt.status === 'cancelled'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-slate-50 text-slate-700 border-slate-200'
                        }`}
                      >
                        <option value="confirmed">Confirmed</option>
                        <option value="in-queue">In Queue</option>
                        <option value="in-consultation">In Consultation</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                        <option value="no-show">No Show</option>
                      </select>
                    </td>

                    <td className="px-5 py-3.5 text-right space-x-1">
                      <button
                        onClick={() => onOpenWritePrescription(apt)}
                        className="px-2.5 py-1.5 rounded-lg text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-100 cursor-pointer"
                        title="Write Prescription"
                      >
                        <FileText className="w-3.5 h-3.5 inline mr-1" />
                        Rx
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
