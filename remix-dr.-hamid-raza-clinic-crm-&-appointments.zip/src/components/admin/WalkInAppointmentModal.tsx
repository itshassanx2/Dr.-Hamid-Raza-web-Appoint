import React, { useState } from 'react';
import {
  X,
  UserPlus,
  Baby,
  User,
  Phone,
  Clock,
  Calendar,
  Building2,
  DollarSign,
  AlertCircle,
} from 'lucide-react';
import { ClinicLocation, Appointment } from '../../types/clinic';
import { api } from '../../services/api';

interface WalkInAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  locations: ClinicLocation[];
  onAppointmentCreated: (appointment: Appointment) => void;
}

export const WalkInAppointmentModal: React.FC<WalkInAppointmentModalProps> = ({
  isOpen,
  onClose,
  locations,
  onAppointmentCreated,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [clinicId, setClinicId] = useState(locations[0]?.id || '');
  const [patientName, setPatientName] = useState('');
  const [patientAgeYears, setPatientAgeYears] = useState(1);
  const [patientAgeMonths, setPatientAgeMonths] = useState(0);
  const [patientGender, setPatientGender] = useState<'Male' | 'Female'>('Male');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [timeSlot, setTimeSlot] = useState('Now (Walk-in)');
  const [reasonForVisit, setReasonForVisit] = useState('Acute Consultation / Walk-in');
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'pending' | 'waived'>('paid');

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const selectedLoc = locations.find((l) => l.id === clinicId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !guardianPhone.trim()) {
      setErrorMsg('Please enter child name and parent phone');
      return;
    }

    setSubmitting(true);
    setErrorMsg('');

    try {
      const apt = await api.createAppointment({
        patientName: patientName.trim(),
        patientAgeYears: Number(patientAgeYears) || 0,
        patientAgeMonths: Number(patientAgeMonths) || 0,
        patientGender,
        guardianName: guardianName.trim() || 'Parent',
        guardianRelation: 'Guardian',
        guardianPhone: guardianPhone.trim(),
        clinicLocationId: clinicId,
        date: todayStr,
        timeSlot: timeSlot || 'Walk-in',
        reasonForVisit: reasonForVisit.trim(),
        isFollowUp: false,
        fee: selectedLoc?.fee || 0,
      });

      // Update to in-queue and payment status
      await api.updateAppointment(apt.id, {
        status: 'in-queue',
        paymentStatus,
      });

      onAppointmentCreated({ ...apt, status: 'in-queue', paymentStatus });
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create walk-in appointment');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden relative">
        <div className="bg-gradient-to-r from-teal-800 to-teal-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <UserPlus className="w-5 h-5 text-teal-300" />
            <div>
              <h3 className="text-base font-bold text-white">Register Walk-in Child Patient</h3>
              <p className="text-[11px] text-teal-200">
                Instantly issues queue token and adds patient to today's doctor queue
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-teal-200 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Clinic Center</label>
            <select
              value={clinicId}
              onChange={(e) => setClinicId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white"
            >
              {locations.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {loc.name} — Fee: Rs. {loc.fee}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Child's Name *</label>
              <input
                type="text"
                required
                placeholder="Child's full name"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
              />
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Gender</label>
              <select
                value={patientGender}
                onChange={(e) => setPatientGender(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
              >
                <option value="Male">Boy (Male)</option>
                <option value="Female">Girl (Female)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Age (Years)</label>
              <input
                type="number"
                min={0}
                max={18}
                value={patientAgeYears}
                onChange={(e) => setPatientAgeYears(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Age (Months)</label>
              <input
                type="number"
                min={0}
                max={11}
                value={patientAgeMonths}
                onChange={(e) => setPatientAgeMonths(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Parent / Guardian Name</label>
              <input
                type="text"
                placeholder="Parent's name"
                value={guardianName}
                onChange={(e) => setGuardianName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Mobile Phone *</label>
              <input
                type="tel"
                required
                placeholder="0300-1234567"
                value={guardianPhone}
                onChange={(e) => setGuardianPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Desk Slot / Time</label>
              <input
                type="text"
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
              />
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Payment Status</label>
              <select
                value={paymentStatus}
                onChange={(e) => setPaymentStatus(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
              >
                <option value="paid">Paid at Counter (Rs. {selectedLoc?.fee || 0})</option>
                <option value="pending">Payment Pending</option>
                <option value="waived">Waived / Free</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Chief Symptoms / Reason for Consultation</label>
            <input
              type="text"
              placeholder="e.g. Acute high fever, vomiting, rash"
              value={reasonForVisit}
              onChange={(e) => setReasonForVisit(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 rounded-xl font-bold text-white bg-teal-700 hover:bg-teal-800 shadow-sm cursor-pointer"
            >
              {submitting ? 'Allocating Token...' : 'Allocate Queue Token'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
