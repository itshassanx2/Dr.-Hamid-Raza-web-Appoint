import React, { useState, useEffect } from 'react';
import {
  FileText,
  Plus,
  Trash2,
  Printer,
  CheckCircle2,
  AlertCircle,
  Building2,
  Stethoscope,
  X,
  Search,
} from 'lucide-react';
import { Appointment, Patient, Prescription, Medication, Vitals } from '../../types/clinic';
import { api } from '../../services/api';

interface PrescriptionWriterProps {
  initialAppointment?: Appointment | null;
  initialPatient?: Patient | null;
  onPrescriptionCreated?: (rx: Prescription) => void;
  onClose?: () => void;
}

export const PrescriptionWriter: React.FC<PrescriptionWriterProps> = ({
  initialAppointment,
  initialPatient,
  onPrescriptionCreated,
  onClose,
}) => {
  // Patient Details
  const [patientName, setPatientName] = useState(
    initialAppointment?.patientName || initialPatient?.childName || ''
  );
  const [ageDisplay, setAgeDisplay] = useState(
    initialAppointment
      ? `${initialAppointment.patientAgeYears}y ${initialAppointment.patientAgeMonths}m`
      : '1 Year'
  );
  const [gender, setGender] = useState<'Male' | 'Female'>(
    initialAppointment?.patientGender || initialPatient?.gender || 'Male'
  );
  const [guardianName, setGuardianName] = useState(
    initialAppointment?.guardianName || initialPatient?.guardianName || ''
  );
  const [patientId, setPatientId] = useState(
    initialAppointment?.patientId || initialPatient?.id || 'pat-general'
  );
  const [appointmentId, setAppointmentId] = useState(initialAppointment?.id || '');

  // Vitals
  const [weightKg, setWeightKg] = useState<string>('10.2');
  const [heightCm, setHeightCm] = useState<string>('78');
  const [headCircumferenceCm, setHeadCircumferenceCm] = useState<string>('46');
  const [temperatureF, setTemperatureF] = useState<string>('98.6');
  const [spo2, setSpo2] = useState<string>('99');

  // Clinical findings
  const [chiefComplaints, setChiefComplaints] = useState<string>(
    initialAppointment?.reasonForVisit || 'Fever, cough, and runny nose for 2 days'
  );
  const [diagnosis, setDiagnosis] = useState<string>('Acute Upper Respiratory Tract Infection (URTI)');
  const [clinicalNotes, setClinicalNotes] = useState<string>(
    'Chest bilateral air entry normal, throat mildly congested, hydration status fair.'
  );

  // Medications
  const [medications, setMedications] = useState<Medication[]>([
    {
      medicineName: 'Syp. Paracetamol (Calpol 120mg/5ml)',
      form: 'Syrup',
      dosage: '4.5 ml',
      frequency: 'SOS (Every 6 hrs if fever > 100°F)',
      duration: '3 days',
      instructions: 'Give with or after feeds. Shake well.',
    },
    {
      medicineName: 'Normal Saline Nasal Drops',
      form: 'Drops',
      dosage: '2 drops in each nostril',
      frequency: 'TDS (Three times daily)',
      duration: '5 days',
      instructions: 'Instill before feeding and before sleep.',
    },
  ]);

  // Advice
  const [adviceText, setAdviceText] = useState<string>(
    'Offer frequent sips of warm water and clear fluids.\nContinue normal breast or formula feeds.\nSteam inhalation for 5 mins twice daily.\nEmergency red flags: rapid breathing, grunting, poor feeding, or lethargy.'
  );
  const [followUpDate, setFollowUpDate] = useState<string>('In 3-5 days if fever or cough persists');

  const [saving, setSaving] = useState(false);
  const [savedRx, setSavedRx] = useState<Prescription | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const addMedicationRow = () => {
    setMedications([
      ...medications,
      {
        medicineName: '',
        form: 'Syrup',
        dosage: '',
        frequency: 'TDS',
        duration: '5 days',
        instructions: 'After meals',
      },
    ]);
  };

  const removeMedicationRow = (index: number) => {
    setMedications(medications.filter((_, i) => i !== index));
  };

  const updateMedication = (index: number, field: keyof Medication, value: string) => {
    const updated = [...medications];
    updated[index] = { ...updated[index], [field]: value };
    setMedications(updated);
  };

  const handleSavePrescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) {
      setErrorMsg('Please enter child name');
      return;
    }
    if (!diagnosis.trim()) {
      setErrorMsg('Please specify clinical diagnosis');
      return;
    }

    setSaving(true);
    setErrorMsg('');

    try {
      const vitals: Vitals = {
        weightKg: weightKg ? Number(weightKg) : undefined,
        heightCm: heightCm ? Number(heightCm) : undefined,
        headCircumferenceCm: headCircumferenceCm ? Number(headCircumferenceCm) : undefined,
        temperatureF: temperatureF ? Number(temperatureF) : undefined,
        spo2: spo2 ? Number(spo2) : undefined,
      };

      const adviceList = adviceText
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean);

      const complaintsList = chiefComplaints
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      const newRx = await api.createPrescription({
        appointmentId: appointmentId || undefined,
        patientId,
        patientName: patientName.trim(),
        ageDisplay,
        gender,
        guardianName: guardianName.trim(),
        date: new Date().toISOString().split('T')[0],
        vitals,
        chiefComplaints: complaintsList,
        diagnosis: diagnosis.trim(),
        clinicalNotes: clinicalNotes.trim(),
        medications: medications.filter((m) => m.medicineName.trim().length > 0),
        advice: adviceList,
        followUpDate,
        doctorName: 'Dr. Hamid Raza',
        doctorDesignation: 'M.B.B.S. (KE), MD (KE) Pediatrics, Senior Registrar Mayo Hospital Lahore',
      });

      setSavedRx(newRx);
      if (onPrescriptionCreated) onPrescriptionCreated(newRx);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save prescription');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs overflow-hidden">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-teal-900 text-white p-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Stethoscope className="w-4 h-4 text-teal-300" />
            <span className="text-xs font-bold text-teal-200 uppercase tracking-wider">
              Pediatric E-Prescription Desk
            </span>
          </div>
          <h3 className="text-xl font-bold text-white mt-1">
            Official Prescription Pad — Dr. Hamid Raza
          </h3>
          <p className="text-xs text-teal-100">
            Consultant Child Specialist &amp; Neonatologist • Senior Registrar Mayo Hospital
          </p>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2 text-teal-200 hover:text-white rounded-xl hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {savedRx ? (
        /* Printable Prescription View */
        <div className="p-8 space-y-6 max-w-3xl mx-auto">
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-800 text-xs font-bold">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span>
                Prescription #{savedRx.prescriptionNumber} generated and saved to patient's EMR record!
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Printer className="w-3.5 h-3.5" />
                Print Official Rx
              </button>
              <button
                onClick={() => setSavedRx(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 cursor-pointer"
              >
                Write Another
              </button>
            </div>
          </div>

          {/* Official Prescription Slip Layout */}
          <div className="border border-slate-300 rounded-3xl p-8 bg-white shadow-sm space-y-6 text-xs text-slate-800 print:border-none print:shadow-none">
            {/* Header */}
            <div className="border-b-2 border-teal-800 pb-4 flex items-start justify-between">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                  Dr. Hamid Raza
                </h2>
                <p className="text-teal-800 font-bold text-sm">
                  M.B.B.S. (KE), MD (KE) Pediatrics
                </p>
                <p className="text-xs text-slate-700 font-semibold">
                  Consultant Child Specialist &amp; Neonatologist
                </p>
                <p className="text-xs text-slate-500">
                  Senior Registrar, Mayo Hospital Lahore • PMDC 58412-P
                </p>
              </div>
              <div className="text-right">
                <span className="font-mono text-sm font-bold text-teal-800 block">
                  {savedRx.prescriptionNumber}
                </span>
                <span className="text-xs text-slate-500 block">Date: {savedRx.date}</span>
              </div>
            </div>

            {/* Patient Bar */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 grid grid-cols-3 gap-3">
              <div>
                <span className="text-[10px] text-slate-400 block font-bold">Child Patient:</span>
                <span className="font-bold text-sm text-slate-900">{savedRx.patientName}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block font-bold">Age / Gender:</span>
                <span className="font-semibold text-slate-900">
                  {savedRx.ageDisplay} • {savedRx.gender}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block font-bold">Guardian:</span>
                <span className="font-semibold text-slate-900">{savedRx.guardianName}</span>
              </div>
            </div>

            {/* Vitals */}
            {savedRx.vitals && (
              <div className="p-2.5 rounded-xl bg-teal-50/50 border border-teal-100 flex flex-wrap gap-4 text-xs font-semibold text-slate-700">
                {savedRx.vitals.weightKg && <span>Weight: {savedRx.vitals.weightKg} kg</span>}
                {savedRx.vitals.heightCm && <span>Height: {savedRx.vitals.heightCm} cm</span>}
                {savedRx.vitals.temperatureF && <span>Temp: {savedRx.vitals.temperatureF} °F</span>}
                {savedRx.vitals.headCircumferenceCm && (
                  <span>OFC: {savedRx.vitals.headCircumferenceCm} cm</span>
                )}
                {savedRx.vitals.spo2 && <span>SpO2: {savedRx.vitals.spo2}%</span>}
              </div>
            )}

            {/* Diagnosis */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-teal-900 block">
                Clinical Diagnosis:
              </span>
              <p className="font-bold text-sm text-slate-900">{savedRx.diagnosis}</p>
              {savedRx.clinicalNotes && <p className="text-slate-600 text-xs">{savedRx.clinicalNotes}</p>}
            </div>

            {/* Rx Medications */}
            <div className="space-y-3 pt-3 border-t border-slate-200">
              <div className="text-xl font-serif font-black text-teal-800">℞</div>
              <div className="space-y-2.5">
                {savedRx.medications.map((m, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <div className="font-bold text-slate-900 text-xs">
                      {idx + 1}. {m.medicineName} ({m.form})
                    </div>
                    <div className="text-slate-700 text-xs mt-0.5">
                      Dosage: <strong className="text-slate-900">{m.dosage}</strong> • Frequency: {m.frequency} • Duration: {m.duration}
                    </div>
                    {m.instructions && (
                      <div className="text-teal-700 text-[11px] mt-0.5 italic">
                        &bull; {m.instructions}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Advice */}
            {savedRx.advice && savedRx.advice.length > 0 && (
              <div className="space-y-1 pt-2 border-t border-slate-200">
                <span className="font-bold text-slate-800 text-xs">Dietary &amp; Nursing Advice:</span>
                <ul className="list-disc list-inside space-y-0.5 text-slate-600 text-xs">
                  {savedRx.advice.map((adv, i) => (
                    <li key={i}>{adv}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Signatures */}
            <div className="pt-8 border-t-2 border-slate-200 flex items-end justify-between">
              <div>
                <span className="text-[10px] text-slate-400 block font-bold">Follow-Up:</span>
                <span className="font-bold text-teal-800 text-xs">{savedRx.followUpDate}</span>
              </div>
              <div className="text-right">
                <div className="h-8 font-serif italic text-teal-800 text-sm font-bold">
                  Dr. Hamid Raza
                </div>
                <div className="text-[10px] text-slate-400 border-t border-slate-300 pt-0.5">
                  Consultant Child Specialist &amp; Neonatologist
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Prescription Creation Form */
        <form onSubmit={handleSavePrescription} className="p-6 space-y-6 text-xs">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Patient particulars */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Child's Name *</label>
              <input
                type="text"
                required
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
              />
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Age Display</label>
              <input
                type="text"
                value={ageDisplay}
                onChange={(e) => setAgeDisplay(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
              />
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
              >
                <option value="Male">Boy (Male)</option>
                <option value="Female">Girl (Female)</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Guardian Name</label>
              <input
                type="text"
                value={guardianName}
                onChange={(e) => setGuardianName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
              />
            </div>
          </div>

          {/* Vitals row */}
          <div className="space-y-2">
            <span className="font-bold text-slate-800 text-xs">Clinical Vitals &amp; Growth Measurements</span>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] text-slate-500 font-semibold">Weight (kg)</label>
                <input
                  type="text"
                  value={weightKg}
                  onChange={(e) => setWeightKg(e.target.value)}
                  placeholder="e.g. 10.5"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-slate-500 font-semibold">Height (cm)</label>
                <input
                  type="text"
                  value={heightCm}
                  onChange={(e) => setHeightCm(e.target.value)}
                  placeholder="e.g. 80"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-slate-500 font-semibold">Head Circ (cm)</label>
                <input
                  type="text"
                  value={headCircumferenceCm}
                  onChange={(e) => setHeadCircumferenceCm(e.target.value)}
                  placeholder="e.g. 46"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-slate-500 font-semibold">Temp (°F)</label>
                <input
                  type="text"
                  value={temperatureF}
                  onChange={(e) => setTemperatureF(e.target.value)}
                  placeholder="98.6"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-slate-500 font-semibold">SpO2 (%)</label>
                <input
                  type="text"
                  value={spo2}
                  onChange={(e) => setSpo2(e.target.value)}
                  placeholder="98"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
            </div>
          </div>

          {/* Complaints & Diagnosis */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Chief Complaints</label>
              <textarea
                rows={2}
                value={chiefComplaints}
                onChange={(e) => setChiefComplaints(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Diagnosis *</label>
              <textarea
                rows={2}
                required
                value={diagnosis}
                onChange={(e) => setDiagnosis(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
          </div>

          {/* Medications Builder */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-base font-serif font-black text-teal-800">℞</span>
                <span className="font-bold text-slate-900 text-xs">Prescribed Pediatric Medications</span>
              </div>
              <button
                type="button"
                onClick={addMedicationRow}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold text-teal-700 bg-teal-50 hover:bg-teal-100 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Medication
              </button>
            </div>

            <div className="space-y-3">
              {medications.map((m, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/60 space-y-2 relative"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                    <div className="sm:col-span-4">
                      <label className="text-[10px] font-bold text-slate-500 block">Medicine Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Syp. Calpol"
                        value={m.medicineName}
                        onChange={(e) => updateMedication(idx, 'medicineName', e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-semibold bg-white"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-[10px] font-bold text-slate-500 block">Form</label>
                      <select
                        value={m.form}
                        onChange={(e) => updateMedication(idx, 'form', e.target.value as any)}
                        className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white"
                      >
                        <option value="Syrup">Syrup</option>
                        <option value="Drops">Drops</option>
                        <option value="Suspension">Suspension</option>
                        <option value="Sachet">Sachet</option>
                        <option value="Tablet">Tablet</option>
                        <option value="Inhaler">Inhaler</option>
                        <option value="Respules">Respules</option>
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-[10px] font-bold text-slate-500 block">Dosage</label>
                      <input
                        type="text"
                        placeholder="e.g. 3.5 ml"
                        value={m.dosage}
                        onChange={(e) => updateMedication(idx, 'dosage', e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-[10px] font-bold text-slate-500 block">Frequency</label>
                      <input
                        type="text"
                        placeholder="e.g. TDS"
                        value={m.frequency}
                        onChange={(e) => updateMedication(idx, 'frequency', e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                      />
                    </div>
                    <div className="sm:col-span-2 flex items-end gap-1">
                      <div className="flex-1">
                        <label className="text-[10px] font-bold text-slate-500 block">Duration</label>
                        <input
                          type="text"
                          placeholder="e.g. 5 days"
                          value={m.duration}
                          onChange={(e) => updateMedication(idx, 'duration', e.target.value)}
                          className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white"
                        />
                      </div>
                      {medications.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeMedicationRow(idx)}
                          className="p-2 text-rose-500 hover:bg-rose-100 rounded-lg cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div>
                    <input
                      type="text"
                      placeholder="Special Instructions (e.g. Give after feeding, dilute in 30ml water)"
                      value={m.instructions}
                      onChange={(e) => updateMedication(idx, 'instructions', e.target.value)}
                      className="w-full px-2.5 py-1 text-[11px] rounded-lg border border-slate-200 bg-white"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Advice & Follow-Up */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">General Pediatric Advice (one per line)</label>
              <textarea
                rows={3}
                value={adviceText}
                onChange={(e) => setAdviceText(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300"
              />
            </div>
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Follow-up Instructions</label>
                <input
                  type="text"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Clinical Examination Notes</label>
                <input
                  type="text"
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
            </div>
          </div>

          {/* Action */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              disabled={saving}
              className="px-7 py-3 rounded-xl font-bold text-xs text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-50 shadow-md flex items-center gap-2 cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              {saving ? 'Generating...' : 'Save & Issue Official Prescription'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
