import React, { useState } from 'react';
import {
  Calendar,
  Search,
  Filter,
  Plus,
  Phone,
  Trash2,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  Building2,
  User,
  Download,
} from 'lucide-react';
import { Appointment, ClinicLocation } from '../../types/clinic';

interface AppointmentsManagerProps {
  appointments: Appointment[];
  locations: ClinicLocation[];
  onUpdateStatus: (id: string, status: Appointment['status']) => Promise<void>;
  onTogglePayment: (id: string, current: 'paid' | 'pending' | 'waived') => Promise<void>;
  onDeleteAppointment: (id: string) => Promise<void>;
  onOpenWritePrescription: (appointment: Appointment) => void;
  onOpenWalkInModal: () => void;
  onViewPatientDetails: (patientId?: string, fallbackApt?: Appointment) => void;
}

export const AppointmentsManager: React.FC<AppointmentsManagerProps> = ({
  appointments,
  locations,
  onUpdateStatus,
  onTogglePayment,
  onDeleteAppointment,
  onOpenWritePrescription,
  onOpenWalkInModal,
  onViewPatientDetails,
}) => {
  const [search, setSearch] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedDateFilter, setSelectedDateFilter] = useState<string>('all');
  const [customDate, setCustomDate] = useState<string>('');

  const todayStr = new Date().toISOString().split('T')[0];

  const filteredAppointments = appointments.filter((apt) => {
    // Search
    if (search.trim()) {
      const q = search.toLowerCase();
      const match =
        apt.patientName.toLowerCase().includes(q) ||
        apt.guardianPhone.includes(q) ||
        apt.bookingReference.toLowerCase().includes(q) ||
        apt.guardianName.toLowerCase().includes(q);
      if (!match) return false;
    }

    // Clinic
    if (selectedLocation !== 'all' && apt.clinicLocationId !== selectedLocation) {
      return false;
    }

    // Status
    if (selectedStatus !== 'all' && apt.status !== selectedStatus) {
      return false;
    }

    // Date
    if (selectedDateFilter === 'today' && apt.date !== todayStr) {
      return false;
    }
    if (selectedDateFilter === 'custom' && customDate && apt.date !== customDate) {
      return false;
    }

    return true;
  });

  const getLocationName = (locId: string) => {
    return locations.find((l) => l.id === locId)?.name || 'Clinic';
  };

  const handleExportCSV = () => {
    const headers = 'Token,BookingRef,Date,Time,PatientName,AgeYears,AgeMonths,Gender,GuardianName,Phone,Location,Fee,Payment,Status,Reason\n';
    const rows = filteredAppointments
      .map((a) =>
        `"${a.tokenNumber}","${a.bookingReference}","${a.date}","${a.timeSlot}","${a.patientName}","${a.patientAgeYears}","${a.patientAgeMonths}","${a.patientGender}","${a.guardianName}","${a.guardianPhone}","${getLocationName(a.clinicLocationId)}","${a.fee}","${a.paymentStatus}","${a.status}","${(a.reasonForVisit || '').replace(/"/g, '""')}"`
      )
      .join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `dr-hamid-appointments-${todayStr}.csv`;
    link.click();
  };

  return (
    <div className="space-y-6">
      {/* Header & Main Actions */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-slate-900">
              Master Appointment Schedule &amp; Bookings
            </h3>
            <p className="text-xs text-slate-500">
              {filteredAppointments.length} matching appointments across clinic branches
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
            <button
              onClick={onOpenWalkInModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Book Walk-In Patient
            </button>
          </div>
        </div>

        {/* Filter controls bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
          {/* Search box */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search child name, phone, or ref (e.g. HR-8101)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 font-semibold"
            />
          </div>

          {/* Date Filter */}
          <select
            value={selectedDateFilter}
            onChange={(e) => setSelectedDateFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white font-semibold"
          >
            <option value="all">All Dates</option>
            <option value="today">Today ({todayStr})</option>
            <option value="custom">Specific Custom Date...</option>
          </select>

          {/* Clinic Location */}
          <select
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white font-semibold"
          >
            <option value="all">All Clinic Centers</option>
            {locations.map((loc) => (
              <option key={loc.id} value={loc.id}>
                {loc.name}
              </option>
            ))}
          </select>

          {/* Status */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white font-semibold"
          >
            <option value="all">All Statuses</option>
            <option value="confirmed">Confirmed</option>
            <option value="in-queue">In Queue</option>
            <option value="in-consultation">In Consultation</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
            <option value="no-show">No Show</option>
          </select>
        </div>

        {/* Custom date picker if selected */}
        {selectedDateFilter === 'custom' && (
          <div className="pt-2 flex items-center gap-3">
            <span className="text-xs font-bold text-slate-700">Select Date:</span>
            <input
              type="date"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-300"
            />
          </div>
        )}
      </div>

      {/* Appointments List / Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold text-[10px] border-b border-slate-100">
              <tr>
                <th className="px-5 py-3">Token &amp; Code</th>
                <th className="px-5 py-3">Date &amp; Slot</th>
                <th className="px-5 py-3">Patient Child</th>
                <th className="px-5 py-3">Guardian &amp; Phone</th>
                <th className="px-5 py-3">Location</th>
                <th className="px-5 py-3">Fee / Payment</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-10 text-center text-slate-400">
                    No appointments match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((apt) => (
                  <tr key={apt.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className="w-8 h-8 rounded-lg bg-teal-50 text-teal-800 font-black text-xs flex items-center justify-center border border-teal-200">
                          #{String(apt.tokenNumber).padStart(2, '0')}
                        </span>
                        <div>
                          <span className="font-mono text-slate-700 font-bold block">{apt.bookingReference}</span>
                        </div>
                      </div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div className="font-bold text-slate-900">{apt.date}</div>
                      <div className="text-[11px] text-teal-700 font-semibold">{apt.timeSlot}</div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div
                        onClick={() => onViewPatientDetails(apt.patientId, apt)}
                        className="font-bold text-slate-900 hover:text-teal-700 cursor-pointer"
                      >
                        {apt.patientName}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {apt.patientAgeYears}y {apt.patientAgeMonths}m • {apt.patientGender}
                        {apt.isFollowUp && (
                          <span className="ml-1 text-[10px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded">
                            Follow-up
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div className="font-semibold text-slate-800">{apt.guardianName}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {apt.guardianPhone}
                      </div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div className="font-semibold text-slate-800 line-clamp-1">
                        {getLocationName(apt.clinicLocationId)}
                      </div>
                      <div className="text-[10px] text-slate-400 line-clamp-1">{apt.reasonForVisit}</div>
                    </td>

                    <td className="px-5 py-3.5">
                      <button
                        onClick={() => onTogglePayment(apt.id, apt.paymentStatus)}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold cursor-pointer transition-colors ${
                          apt.paymentStatus === 'paid'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : apt.paymentStatus === 'waived'
                            ? 'bg-slate-100 text-slate-600'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {apt.paymentStatus === 'paid'
                          ? `Paid (Rs. ${apt.fee})`
                          : apt.paymentStatus === 'waived'
                          ? 'Waived (Free)'
                          : `Pending (Rs. ${apt.fee})`}
                      </button>
                    </td>

                    <td className="px-5 py-3.5">
                      <select
                        value={apt.status}
                        onChange={(e) => onUpdateStatus(apt.id, e.target.value as any)}
                        className={`text-xs font-bold px-2 py-1 rounded-lg border focus:outline-none cursor-pointer ${
                          apt.status === 'in-consultation'
                            ? 'bg-amber-50 text-amber-800 border-amber-300'
                            : apt.status === 'in-queue'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : apt.status === 'completed'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : apt.status === 'cancelled'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-slate-50 text-slate-700 border-slate-200'
                        }`}
                      >
                        <option value="confirmed">Confirmed</option>
                        <option value="in-queue">In Queue</option>
                        <option value="in-consultation">In Consultation</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                        <option value="no-show">No Show</option>
                      </select>
                    </td>

                    <td className="px-5 py-3.5 text-right space-x-1">
                      <button
                        onClick={() => onOpenWritePrescription(apt)}
                        className="px-2.5 py-1.5 rounded-lg text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-100 cursor-pointer"
                        title="Write Digital Prescription"
                      >
                        <FileText className="w-3.5 h-3.5 inline mr-1" />
                        Rx
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Cancel appointment ${apt.bookingReference} for ${apt.patientName}?`)) {
                            onDeleteAppointment(apt.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer transition-colors"
                        title="Delete / Cancel"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
