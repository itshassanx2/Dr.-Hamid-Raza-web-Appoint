import React, { useState, useEffect } from 'react';
import {
  Baby,
  Search,
  Plus,
  Phone,
  Calendar,
  FileText,
  Activity,
  ShieldCheck,
  AlertTriangle,
  Syringe,
  X,
  CheckCircle2,
  Clock,
  Printer,
  ChevronRight,
  User,
} from 'lucide-react';
import { Patient, Prescription, VaccineRecord, Appointment } from '../../types/clinic';
import { api } from '../../services/api';

interface PatientsEMRProps {
  onOpenWritePrescription: (patient: Patient) => void;
  selectedPatientId?: string;
  onClearSelectedPatient?: () => void;
}

export const PatientsEMR: React.FC<PatientsEMRProps> = ({
  onOpenWritePrescription,
  selectedPatientId,
  onClearSelectedPatient,
}) => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);

  // Active Selected Patient Details Drawer
  const [activePatientId, setActivePatientId] = useState<string | null>(selectedPatientId || null);
  const [patientDetails, setPatientDetails] = useState<{
    patient: Patient;
    prescriptions: Prescription[];
    vaccinations: VaccineRecord[];
    appointments: Appointment[];
  } | null>(null);
  const [loadingDetails, setLoadingDetails] = useState(false);

  // New Patient Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newChildName, setNewChildName] = useState('');
  const [newGender, setNewGender] = useState<'Male' | 'Female'>('Male');
  const [newDob, setNewDob] = useState('2025-01-01');
  const [newBloodGroup, setNewBloodGroup] = useState('Unknown');
  const [newAllergies, setNewAllergies] = useState('');
  const [newGuardianName, setNewGuardianName] = useState('');
  const [newGuardianPhone, setNewGuardianPhone] = useState('');
  const [newAddress, setNewAddress] = useState('Lahore');
  const [newBirthWeight, setNewBirthWeight] = useState<number>(3.2);
  const [newHistoryNotes, setNewHistoryNotes] = useState('');
  const [savingPatient, setSavingPatient] = useState(false);

  // Vaccine modal state
  const [vaccineModalOpen, setVaccineModalOpen] = useState(false);
  const [vaccineName, setVaccineName] = useState('');
  const [vaccineTargetAge, setVaccineTargetAge] = useState('At Birth');
  const [vaccineDueDate, setVaccineDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [vaccineBatch, setVaccineBatch] = useState('');

  // Selected prescription preview
  const [viewingRx, setViewingRx] = useState<Prescription | null>(null);

  const loadPatients = async () => {
    setLoading(true);
    try {
      const data = await api.getPatients(search);
      setPatients(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPatients();
  }, [search]);

  useEffect(() => {
    if (selectedPatientId) {
      setActivePatientId(selectedPatientId);
    }
  }, [selectedPatientId]);

  useEffect(() => {
    if (!activePatientId) {
      setPatientDetails(null);
      return;
    }
    setLoadingDetails(true);
    api
      .getPatientDetails(activePatientId)
      .then((data) => setPatientDetails(data))
      .catch((err) => console.error(err))
      .finally(() => setLoadingDetails(false));
  }, [activePatientId]);

  const handleCreatePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChildName.trim() || !newGuardianPhone.trim()) return;
    setSavingPatient(true);

    try {
      const created = await api.createPatient({
        childName: newChildName.trim(),
        dob: newDob,
        gender: newGender,
        bloodGroup: newBloodGroup,
        allergies: newAllergies ? newAllergies.split(',').map((s) => s.trim()) : [],
        guardianName: newGuardianName.trim(),
        guardianPhone: newGuardianPhone.trim(),
        address: newAddress.trim(),
        birthWeightKg: Number(newBirthWeight) || undefined,
        historyNotes: newHistoryNotes.trim(),
      });

      setShowAddModal(false);
      loadPatients();
      setActivePatientId(created.id);
    } catch (err) {
      console.error(err);
    } finally {
      setSavingPatient(false);
    }
  };

  const handleAddVaccine = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatientId || !vaccineName) return;

    try {
      await api.recordVaccination({
        patientId: activePatientId,
        vaccineName,
        targetAge: vaccineTargetAge,
        dueDate: vaccineDueDate,
        administeredDate: new Date().toISOString().split('T')[0],
        status: 'completed',
        batchNo: vaccineBatch || 'BC-01',
      });
      setVaccineModalOpen(false);
      // Reload details
      const updated = await api.getPatientDetails(activePatientId);
      setPatientDetails(updated);
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleVaccineStatus = async (record: VaccineRecord) => {
    const newStatus = record.status === 'completed' ? 'pending' : 'completed';
    const administeredDate =
      newStatus === 'completed' ? new Date().toISOString().split('T')[0] : undefined;

    try {
      await api.updateVaccination(record.id, {
        status: newStatus,
        administeredDate,
      });
      if (activePatientId) {
        const updated = await api.getPatientDetails(activePatientId);
        setPatientDetails(updated);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-slate-900">
            Pediatric Electronic Medical Records (EMR)
          </h3>
          <p className="text-xs text-slate-500">
            Patient history, pediatric prescriptions, growth assessment, and immunization records
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search child name, MRN, phone..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 w-64 focus:outline-none focus:ring-2 focus:ring-teal-500 font-semibold"
            />
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            New Child Patient
          </button>
        </div>
      </div>

      {/* Patients Grid / Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {patients.map((pat) => (
          <div
            key={pat.id}
            onClick={() => setActivePatientId(pat.id)}
            className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
              activePatientId === pat.id
                ? 'border-teal-600 bg-teal-50/40 shadow-sm ring-2 ring-teal-500/30'
                : 'border-slate-200 bg-white hover:border-slate-300 shadow-2xs hover:-translate-y-0.5'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-sm">
                    {pat.gender === 'Male' ? '👦' : '👧'}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 line-clamp-1">{pat.childName}</h4>
                    <span className="text-[10px] font-mono text-teal-700 font-bold">{pat.mrn}</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                  {pat.gender}
                </span>
              </div>

              <div className="space-y-1 text-xs text-slate-600 pt-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Guardian:</span>
                  <span className="font-semibold text-slate-800">{pat.guardianName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Phone:</span>
                  <span className="font-semibold text-slate-800">{pat.guardianPhone}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Blood Group:</span>
                  <span className="font-semibold text-slate-800">{pat.bloodGroup || 'Not Tested'}</span>
                </div>
              </div>

              {pat.allergies && pat.allergies.length > 0 && (
                <div className="p-1.5 rounded-lg bg-rose-50 border border-rose-200 text-[10px] text-rose-700 flex items-center gap-1 font-semibold">
                  <AlertTriangle className="w-3 h-3 shrink-0" />
                  <span className="line-clamp-1">Allergy: {pat.allergies.join(', ')}</span>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-[11px] text-slate-400">DOB: {pat.dob}</span>
              <span className="font-bold text-teal-700 flex items-center gap-1 text-[11px]">
                View Full EMR &rarr;
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Detailed Patient EMR Drawer / Modal */}
      {activePatientId && patientDetails && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full border border-slate-200 overflow-hidden relative animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="bg-gradient-to-r from-slate-900 to-teal-950 text-white p-6 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-teal-600/50 border border-teal-400/30 flex items-center justify-center text-white text-2xl font-black">
                  {patientDetails.patient.gender === 'Male' ? '👦' : '👧'}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-black text-white">
                      {patientDetails.patient.childName}
                    </h3>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-500/30 text-teal-200 border border-teal-400/30">
                      {patientDetails.patient.mrn}
                    </span>
                  </div>
                  <p className="text-xs text-teal-200 mt-0.5">
                    Guardian: {patientDetails.patient.guardianName} • Phone: {patientDetails.patient.guardianPhone}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenWritePrescription(patientDetails.patient)}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-900 bg-amber-300 hover:bg-amber-200 flex items-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  New Prescription
                </button>
                <button
                  onClick={() => {
                    setActivePatientId(null);
                    if (onClearSelectedPatient) onClearSelectedPatient();
                  }}
                  className="p-2 text-teal-200 hover:text-white rounded-xl hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Patient Core Summary Banner */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <span className="text-slate-400 block text-[10px]">Date of Birth</span>
                  <span className="font-bold text-slate-900">{patientDetails.patient.dob}</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <span className="text-slate-400 block text-[10px]">Blood Group</span>
                  <span className="font-bold text-slate-900">{patientDetails.patient.bloodGroup || 'N/A'}</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <span className="text-slate-400 block text-[10px]">Birth Weight / Gestation</span>
                  <span className="font-bold text-slate-900">
                    {patientDetails.patient.birthWeightKg ? `${patientDetails.patient.birthWeightKg} kg` : 'N/A'} • {patientDetails.patient.gestationalWeeks ? `${patientDetails.patient.gestationalWeeks} wks` : 'Term'}
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <span className="text-slate-400 block text-[10px]">Known Allergies</span>
                  <span className="font-bold text-rose-700">
                    {patientDetails.patient.allergies?.length ? patientDetails.patient.allergies.join(', ') : 'None Reported'}
                  </span>
                </div>
              </div>

              {/* History note */}
              {patientDetails.patient.historyNotes && (
                <div className="p-3.5 rounded-2xl bg-teal-50/60 border border-teal-100 text-xs space-y-1">
                  <span className="font-bold text-teal-900">Clinical Background / Medical Notes:</span>
                  <p className="text-slate-700">{patientDetails.patient.historyNotes}</p>
                </div>
              )}

              {/* SECTION: Immunization & Vaccines */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Syringe className="w-4 h-4 text-teal-700" />
                    <h4 className="font-bold text-sm text-slate-900">
                      Child Immunization &amp; Vaccination Schedule
                    </h4>
                  </div>
                  <button
                    onClick={() => setVaccineModalOpen(true)}
                    className="text-xs font-bold text-teal-700 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Record Vaccine Dose
                  </button>
                </div>

                <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold">
                      <tr>
                        <th className="px-4 py-2.5">Vaccine</th>
                        <th className="px-4 py-2.5">Target Age</th>
                        <th className="px-4 py-2.5">Due Date</th>
                        <th className="px-4 py-2.5">Administered</th>
                        <th className="px-4 py-2.5">Status</th>
                        <th className="px-4 py-2.5 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {patientDetails.vaccinations.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-4 py-4 text-center text-slate-400">
                            No vaccinations recorded yet. Click 'Record Vaccine Dose' to add.
                          </td>
                        </tr>
                      ) : (
                        patientDetails.vaccinations.map((vac) => (
                          <tr key={vac.id} className="hover:bg-slate-50">
                            <td className="px-4 py-2.5 font-bold text-slate-900">{vac.vaccineName}</td>
                            <td className="px-4 py-2.5 text-slate-600">{vac.targetAge}</td>
                            <td className="px-4 py-2.5 text-slate-600">{vac.dueDate}</td>
                            <td className="px-4 py-2.5 text-slate-800">
                              {vac.administeredDate || '—'}
                              {vac.batchNo && <span className="text-[10px] text-slate-400 ml-1">({vac.batchNo})</span>}
                            </td>
                            <td className="px-4 py-2.5">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  vac.status === 'completed'
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-amber-50 text-amber-700 border border-amber-200'
                                }`}
                              >
                                {vac.status === 'completed' ? 'Administered' : 'Due / Pending'}
                              </span>
                            </td>
                            <td className="px-4 py-2.5 text-right">
                              <button
                                onClick={() => handleToggleVaccineStatus(vac)}
                                className="px-2 py-1 rounded text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                              >
                                {vac.status === 'completed' ? 'Mark Due' : 'Mark Done'}
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SECTION: Past Prescriptions */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-teal-700" />
                  <h4 className="font-bold text-sm text-slate-900">
                    Previous Prescriptions &amp; Clinical Notes ({patientDetails.prescriptions.length})
                  </h4>
                </div>

                <div className="space-y-3">
                  {patientDetails.prescriptions.length === 0 ? (
                    <div className="p-4 rounded-2xl bg-slate-50 text-center text-xs text-slate-400">
                      No prescriptions on file yet for this patient.
                    </div>
                  ) : (
                    patientDetails.prescriptions.map((rx) => (
                      <div
                        key={rx.id}
                        className="p-4 rounded-2xl border border-slate-200 bg-white space-y-3 hover:border-teal-300 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-mono text-xs font-bold text-teal-700">{rx.prescriptionNumber}</span>
                            <span className="text-xs text-slate-400 ml-2">{rx.date}</span>
                          </div>
                          <button
                            onClick={() => setViewingRx(rx)}
                            className="px-3 py-1 rounded-lg text-xs font-bold text-teal-700 bg-teal-50 hover:bg-teal-100 cursor-pointer flex items-center gap-1"
                          >
                            <Printer className="w-3 h-3" />
                            View &amp; Print Slip
                          </button>
                        </div>

                        <div className="text-xs space-y-1">
                          <div className="font-bold text-slate-800">Diagnosis: {rx.diagnosis}</div>
                          {rx.clinicalNotes && <p className="text-slate-500">{rx.clinicalNotes}</p>}
                        </div>

                        {/* Medications Summary */}
                        <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-2 text-[11px]">
                          {rx.medications.map((m, idx) => (
                            <span key={idx} className="px-2.5 py-1 rounded-md bg-slate-100 font-semibold text-slate-700">
                              {m.medicineName} ({m.dosage} • {m.frequency})
                            </span>
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add New Child Patient */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden relative">
            <div className="bg-gradient-to-r from-teal-800 to-teal-900 text-white p-5 flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Register New Pediatric Patient</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-teal-200 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePatient} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Child's Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Full name"
                    value={newChildName}
                    onChange={(e) => setNewChildName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 font-semibold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Gender</label>
                  <select
                    value={newGender}
                    onChange={(e) => setNewGender(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Date of Birth</label>
                  <input
                    type="date"
                    value={newDob}
                    onChange={(e) => setNewDob(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Blood Group</label>
                  <select
                    value={newBloodGroup}
                    onChange={(e) => setNewBloodGroup(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  >
                    <option value="Unknown">Unknown</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Guardian Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Parent's Name"
                    value={newGuardianName}
                    onChange={(e) => setNewGuardianName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Guardian Mobile Phone *</label>
                  <input
                    type="tel"
                    required
                    placeholder="0300-1234567"
                    value={newGuardianPhone}
                    onChange={(e) => setNewGuardianPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Birth Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newBirthWeight}
                    onChange={(e) => setNewBirthWeight(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Known Allergies (comma separated)</label>
                  <input
                    type="text"
                    placeholder="e.g. Penicillin, Eggs"
                    value={newAllergies}
                    onChange={(e) => setNewAllergies(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Medical Background Notes</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Preterm at 35 weeks, treated for jaundice at Mayo Hospital"
                  value={newHistoryNotes}
                  onChange={(e) => setNewHistoryNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingPatient}
                  className="px-5 py-2 rounded-xl text-white bg-teal-700 hover:bg-teal-800 font-bold"
                >
                  {savingPatient ? 'Saving...' : 'Register Patient'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Record Vaccine */}
      {vaccineModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="bg-teal-800 text-white p-4 flex items-center justify-between">
              <h4 className="font-bold text-sm">Record Administered Vaccine</h4>
              <button
                onClick={() => setVaccineModalOpen(false)}
                className="text-teal-200 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddVaccine} className="p-5 space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Vaccine Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Pentavalent-1 or Typhoid TCV"
                  value={vaccineName}
                  onChange={(e) => setVaccineName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                />
              </div>
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Target Age</label>
                <input
                  type="text"
                  placeholder="e.g. 6 Weeks, 9 Months"
                  value={vaccineTargetAge}
                  onChange={(e) => setVaccineTargetAge(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Batch / Lot Number</label>
                <input
                  type="text"
                  placeholder="e.g. PENT-9941"
                  value={vaccineBatch}
                  onChange={(e) => setVaccineBatch(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setVaccineModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg font-bold bg-teal-700 text-white"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Prescription Print Modal */}
      {viewingRx && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden relative">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <span className="font-bold text-sm">Official Medical Prescription Slip</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1 rounded-lg text-xs font-bold bg-teal-600 hover:bg-teal-700 text-white flex items-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Slip
                </button>
                <button onClick={() => setViewingRx(null)} className="p-1 text-slate-300 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Authentic Clinical Prescription Layout */}
            <div className="p-8 space-y-6 text-slate-800 text-xs">
              {/* Doctor Official Header */}
              <div className="border-b-2 border-teal-800 pb-4 flex items-start justify-between">
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight">
                    {viewingRx.doctorName || 'Dr. Hamid Raza'}
                  </h2>
                  <p className="text-teal-700 font-bold text-xs">
                    M.B.B.S. (KE), MD (KE) Pediatrics
                  </p>
                  <p className="text-[11px] text-slate-600 font-semibold">
                    Consultant Child Specialist &amp; Neonatologist
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Senior Registrar, Mayo Hospital Lahore
                  </p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-xs font-bold text-teal-800 block">
                    {viewingRx.prescriptionNumber}
                  </span>
                  <span className="text-[11px] text-slate-500 block">Date: {viewingRx.date}</span>
                </div>
              </div>

              {/* Patient bar */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-3 gap-2">
                <div>
                  <span className="text-[10px] text-slate-400 block">Child Patient:</span>
                  <span className="font-bold text-slate-900">{viewingRx.patientName}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Age / Gender:</span>
                  <span className="font-semibold text-slate-900">
                    {viewingRx.ageDisplay} • {viewingRx.gender}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Guardian:</span>
                  <span className="font-semibold text-slate-900">{viewingRx.guardianName}</span>
                </div>
              </div>

              {/* Vitals */}
              {viewingRx.vitals && (
                <div className="flex flex-wrap gap-3 text-[11px] font-semibold text-slate-700 p-2.5 rounded-lg bg-teal-50/50 border border-teal-100">
                  {viewingRx.vitals.weightKg && <span>Wt: {viewingRx.vitals.weightKg} kg</span>}
                  {viewingRx.vitals.heightCm && <span>Ht: {viewingRx.vitals.heightCm} cm</span>}
                  {viewingRx.vitals.temperatureF && <span>Temp: {viewingRx.vitals.temperatureF} °F</span>}
                  {viewingRx.vitals.headCircumferenceCm && (
                    <span>OFC: {viewingRx.vitals.headCircumferenceCm} cm</span>
                  )}
                  {viewingRx.vitals.spo2 && <span>SpO2: {viewingRx.vitals.spo2}%</span>}
                </div>
              )}

              {/* Diagnosis */}
              <div className="space-y-1">
                <span className="font-bold text-teal-900 uppercase text-[10px] tracking-wider block">
                  Diagnosis:
                </span>
                <p className="font-bold text-sm text-slate-900">{viewingRx.diagnosis}</p>
                {viewingRx.clinicalNotes && <p className="text-slate-600">{viewingRx.clinicalNotes}</p>}
              </div>

              {/* Rx Medications */}
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="text-lg font-serif font-black text-teal-800">℞</div>
                <div className="space-y-2">
                  {viewingRx.medications.map((m, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start justify-between"
                    >
                      <div>
                        <div className="font-bold text-slate-900 text-xs">
                          {idx + 1}. {m.medicineName} ({m.form})
                        </div>
                        <div className="text-slate-600 text-[11px] mt-0.5">
                          Dosage: <strong className="text-slate-800">{m.dosage}</strong> • Frequency: {m.frequency} • Duration: {m.duration}
                        </div>
                        {m.instructions && (
                          <div className="text-teal-700 text-[10px] mt-0.5 italic">
                            &bull; {m.instructions}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Advice */}
              {viewingRx.advice && viewingRx.advice.length > 0 && (
                <div className="space-y-1 pt-2 border-t border-slate-200">
                  <span className="font-bold text-slate-800 text-xs">General Pediatric Advice:</span>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-600 text-[11px]">
                    {viewingRx.advice.map((adv, i) => (
                      <li key={i}>{adv}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Follow-up & Doctor signature */}
              <div className="pt-6 border-t-2 border-slate-200 flex items-end justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">Follow-up:</span>
                  <span className="font-bold text-teal-800 text-xs">
                    {viewingRx.followUpDate || 'As needed or SOS in emergency'}
                  </span>
                </div>
                <div className="text-right">
                  <div className="h-8 font-serif italic text-teal-800 text-sm">Dr. Hamid Raza</div>
                  <div className="text-[10px] text-slate-400 border-t border-slate-300 pt-0.5">
                    Authorized Medical Signature
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
