import React, { useState, useEffect } from 'react';
import {
  Activity,
  Calendar,
  Users,
  FileText,
  Settings,
  LogOut,
  Stethoscope,
  Globe,
  Bell,
  CheckCircle,
  Plus,
  RefreshCw,
  Building2,
} from 'lucide-react';
import {
  ClinicSettings,
  Appointment,
  Patient,
  Prescription,
  ClinicStats,
} from '../../types/clinic';
import { api } from '../../services/api';
import { LiveQueueDashboard } from './LiveQueueDashboard';
import { AppointmentsManager } from './AppointmentsManager';
import { PatientsEMR } from './PatientsEMR';
import { PrescriptionWriter } from './PrescriptionWriter';
import { ClinicSettingsManager } from './ClinicSettingsManager';
import { WalkInAppointmentModal } from './WalkInAppointmentModal';

interface AdminLayoutProps {
  settings: ClinicSettings;
  onSettingsUpdated: (updated: ClinicSettings) => void;
  currentUser: { username: string; name: string; role: string; designation: string };
  onLogout: () => void;
  onReturnToWebsite: () => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  settings,
  onSettingsUpdated,
  currentUser,
  onLogout,
  onReturnToWebsite,
}) => {
  const [activeTab, setActiveTab] = useState<
    'queue' | 'appointments' | 'patients' | 'prescription' | 'settings'
  >('queue');

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [stats, setStats] = useState<ClinicStats | null>(null);
  const [loading, setLoading] = useState(false);

  // Selected state for prescription or EMR drilldown
  const [prescriptionTargetAppointment, setPrescriptionTargetAppointment] =
    useState<Appointment | null>(null);
  const [prescriptionTargetPatient, setPrescriptionTargetPatient] = useState<Patient | null>(null);
  const [selectedPatientIdForEMR, setSelectedPatientIdForEMR] = useState<string | undefined>(
    undefined
  );

  // Walk-in modal
  const [walkInModalOpen, setWalkInModalOpen] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  const loadData = async () => {
    try {
      setLoading(true);
      const [apts, st] = await Promise.all([api.getAppointments(), api.getStats()]);
      setAppointments(apts);
      setStats(st);
    } catch (err) {
      console.error('Failed to load CRM data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleUpdateStatus = async (id: string, status: Appointment['status']) => {
    try {
      const updated = await api.updateAppointment(id, { status });
      setAppointments((prev) => prev.map((a) => (a.id === id ? updated : a)));
      // Refresh stats
      const st = await api.getStats();
      setStats(st);
    } catch (err) {
      console.error(err);
    }
  };

  const handleTogglePayment = async (
    id: string,
    current: 'paid' | 'pending' | 'waived'
  ) => {
    const nextStatus = current === 'paid' ? 'pending' : 'paid';
    try {
      const updated = await api.updateAppointment(id, { paymentStatus: nextStatus });
      setAppointments((prev) => prev.map((a) => (a.id === id ? updated : a)));
      const st = await api.getStats();
      setStats(st);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteAppointment = async (id: string) => {
    try {
      await api.deleteAppointment(id);
      setAppointments((prev) => prev.filter((a) => a.id !== id));
      const st = await api.getStats();
      setStats(st);
    } catch (err) {
      console.error(err);
    }
  };

  const handleOpenPrescriptionForAppointment = (appointment: Appointment) => {
    setPrescriptionTargetAppointment(appointment);
    setPrescriptionTargetPatient(null);
    setActiveTab('prescription');
  };

  const handleOpenPrescriptionForPatient = (patient: Patient) => {
    setPrescriptionTargetPatient(patient);
    setPrescriptionTargetAppointment(null);
    setActiveTab('prescription');
  };

  const handleViewPatientDetails = (patientId?: string, fallbackApt?: Appointment) => {
    if (patientId) {
      setSelectedPatientIdForEMR(patientId);
    }
    setActiveTab('patients');
  };

  const todayAppointments = appointments.filter((a) => a.date === todayStr);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Top CRM App Bar */}
      <header className="bg-slate-900 text-white sticky top-0 z-40 border-b border-slate-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Branding & Role */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-xs">
                <Stethoscope className="w-5 h-5 text-teal-100" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-base tracking-tight text-white">
                    {settings.doctor.name}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-400/30">
                    CRM Portal
                  </span>
                </div>
                <div className="text-[11px] text-teal-200/80">
                  Logged in as <strong className="text-white">{currentUser.name}</strong> ({currentUser.role === 'doctor' ? 'Consultant' : 'Front Desk'})
                </div>
              </div>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2.5">
              <button
                onClick={loadData}
                disabled={loading}
                className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="Refresh Live Data"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-teal-400' : ''}`} />
              </button>

              <button
                onClick={onReturnToWebsite}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-teal-200 bg-teal-900/50 hover:bg-teal-900 border border-teal-700/50 transition-colors cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Public Website</span>
              </button>

              <button
                onClick={onLogout}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 hover:text-white hover:bg-rose-950/40 hover:border-rose-700/50 border border-slate-800 transition-colors cursor-pointer"
                title="Log Out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs Bar */}
          <div className="flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-800 text-xs font-bold scrollbar-none">
            <button
              onClick={() => setActiveTab('queue')}
              className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'queue'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>Live Queue &amp; Caller</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20 text-white">
                {todayAppointments.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('appointments')}
              className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'appointments'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Appointments Schedule</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20 text-white">
                {appointments.length}
              </span>
            </button>

            <button
              onClick={() => {
                setSelectedPatientIdForEMR(undefined);
                setActiveTab('patients');
              }}
              className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'patients'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Patients &amp; EMR</span>
            </button>

            <button
              onClick={() => setActiveTab('prescription')}
              className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'prescription'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Write Prescription (Rx)</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'settings'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Clinic &amp; Doctor Settings</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        {activeTab === 'queue' && (
          <LiveQueueDashboard
            stats={stats}
            todayAppointments={todayAppointments}
            locations={settings.locations}
            onUpdateStatus={handleUpdateStatus}
            onTogglePayment={handleTogglePayment}
            onOpenWritePrescription={handleOpenPrescriptionForAppointment}
            onOpenWalkInModal={() => setWalkInModalOpen(true)}
            onViewPatientDetails={handleViewPatientDetails}
          />
        )}

        {activeTab === 'appointments' && (
          <AppointmentsManager
            appointments={appointments}
            locations={settings.locations}
            onUpdateStatus={handleUpdateStatus}
            onTogglePayment={handleTogglePayment}
            onDeleteAppointment={handleDeleteAppointment}
            onOpenWritePrescription={handleOpenPrescriptionForAppointment}
            onOpenWalkInModal={() => setWalkInModalOpen(true)}
            onViewPatientDetails={handleViewPatientDetails}
          />
        )}

        {activeTab === 'patients' && (
          <PatientsEMR
            selectedPatientId={selectedPatientIdForEMR}
            onClearSelectedPatient={() => setSelectedPatientIdForEMR(undefined)}
            onOpenWritePrescription={handleOpenPrescriptionForPatient}
          />
        )}

        {activeTab === 'prescription' && (
          <PrescriptionWriter
            initialAppointment={prescriptionTargetAppointment}
            initialPatient={prescriptionTargetPatient}
            onPrescriptionCreated={(_rx) => {
              loadData();
            }}
          />
        )}

        {activeTab === 'settings' && (
          <ClinicSettingsManager
            settings={settings}
            onSettingsUpdated={(newSettings) => {
              onSettingsUpdated(newSettings);
            }}
          />
        )}
      </main>

      {/* Walk-in Modal */}
      {walkInModalOpen && (
        <WalkInAppointmentModal
          isOpen={walkInModalOpen}
          onClose={() => setWalkInModalOpen(false)}
          locations={settings.locations}
          onAppointmentCreated={(_newApt) => {
            loadData();
          }}
        />
      )}
    </div>
  );
};
