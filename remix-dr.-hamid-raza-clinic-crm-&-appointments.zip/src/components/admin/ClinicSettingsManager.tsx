import React, { useState } from 'react';
import {
  Settings,
  Building2,
  Stethoscope,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Clock,
  MapPin,
  DollarSign,
  Phone,
  Mail,
  Shield,
} from 'lucide-react';
import { ClinicSettings, ClinicLocation, FAQItem } from '../../types/clinic';
import { api } from '../../services/api';

interface ClinicSettingsManagerProps {
  settings: ClinicSettings;
  onSettingsUpdated: (updated: ClinicSettings) => void;
}

export const ClinicSettingsManager: React.FC<ClinicSettingsManagerProps> = ({
  settings,
  onSettingsUpdated,
}) => {
  // Doctor Profile Form
  const [doctorName, setDoctorName] = useState(settings.doctor.name);
  const [qualifications, setQualifications] = useState(settings.doctor.qualifications);
  const [specialization, setSpecialization] = useState(settings.doctor.specialization);
  const [designation, setDesignation] = useState(settings.doctor.designation);
  const [hospitalAffiliation, setHospitalAffiliation] = useState(
    settings.doctor.hospitalAffiliation
  );
  const [pmdcNumber, setPmdcNumber] = useState(settings.doctor.pmdcNumber);
  const [phone, setPhone] = useState(settings.doctor.phone);
  const [email, setEmail] = useState(settings.doctor.email);
  const [about, setAbout] = useState(settings.doctor.about);

  // Clinic Locations Form
  const [locations, setLocations] = useState<ClinicLocation[]>(settings.locations);

  // Scheduling & Emergency
  const [intervalMinutes, setIntervalMinutes] = useState(settings.appointmentIntervalMinutes);
  const [maxPerSlot, setMaxPerSlot] = useState(settings.maxPatientsPerSlot);
  const [emergencyContact, setEmergencyContact] = useState(settings.emergencyContact);

  // FAQs
  const [faqs, setFaqs] = useState<FAQItem[]>(settings.faqs);

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleUpdateLocation = (index: number, field: keyof ClinicLocation, value: any) => {
    const updated = [...locations];
    updated[index] = { ...updated[index], [field]: value };
    setLocations(updated);
  };

  const handleAddLocation = () => {
    const newLoc: ClinicLocation = {
      id: `loc-${Date.now()}`,
      name: 'New Consultation Clinic',
      tagline: 'Outpatient Pediatric Care',
      address: 'Clinic Address, Lahore',
      city: 'Lahore',
      days: 'Monday to Friday',
      timings: '06:00 PM – 09:00 PM',
      fee: 2500,
      phone: '+92 300 0000000',
      isDefault: false,
      type: 'private_clinic',
    };
    setLocations([...locations, newLoc]);
  };

  const handleRemoveLocation = (index: number) => {
    if (locations.length <= 1) {
      alert('At least one clinic location is required.');
      return;
    }
    setLocations(locations.filter((_, i) => i !== index));
  };

  const handleSaveAll = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      const payload: Partial<ClinicSettings> = {
        doctor: {
          name: doctorName.trim(),
          qualifications: qualifications.trim(),
          specialization: specialization.trim(),
          designation: designation.trim(),
          hospitalAffiliation: hospitalAffiliation.trim(),
          about: about.trim(),
          experienceYears: settings.doctor.experienceYears,
          pmdcNumber: pmdcNumber.trim(),
          phone: phone.trim(),
          email: email.trim(),
        },
        locations,
        appointmentIntervalMinutes: Number(intervalMinutes) || 20,
        maxPatientsPerSlot: Number(maxPerSlot) || 2,
        emergencyContact: emergencyContact.trim(),
        faqs,
      };

      const updated = await api.updateClinicInfo(payload);
      onSettingsUpdated(updated);
      setSuccessMsg('Clinic configuration and doctor profile updated successfully!');
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update clinic settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSaveAll} className="space-y-8 text-xs">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-teal-800 font-bold">
            <Settings className="w-4 h-4 text-teal-600" />
            <span>Clinic CRM &amp; Portal Configuration</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mt-1">
            Clinic Schedules, Locations &amp; Doctor Profile
          </h3>
          <p className="text-xs text-slate-500">
            All details (addresses, timings, consultation fees, and hospital affiliations) are fully configurable.
          </p>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-50 shadow-sm cursor-pointer"
        >
          <Save className="w-4 h-4" />
          {saving ? 'Saving Changes...' : 'Save Configuration'}
        </button>
      </div>

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 font-bold flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-rose-600" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* SECTION 1: Doctor Profile */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-5">
        <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
          <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-900">Doctor Profile &amp; Hospital Credentials</h4>
            <p className="text-[11px] text-slate-500">Displayed on the public website and prescription slips</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Doctor's Full Name</label>
            <input
              type="text"
              required
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Qualifications</label>
            <input
              type="text"
              required
              value={qualifications}
              onChange={(e) => setQualifications(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Clinical Specialization</label>
            <input
              type="text"
              required
              value={specialization}
              onChange={(e) => setSpecialization(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Designation &amp; Hospital Role</label>
            <input
              type="text"
              required
              value={designation}
              onChange={(e) => setDesignation(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Hospital / Institutional Affiliation</label>
            <input
              type="text"
              required
              value={hospitalAffiliation}
              onChange={(e) => setHospitalAffiliation(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">PMDC / PMC Registration Number</label>
            <input
              type="text"
              required
              value={pmdcNumber}
              onChange={(e) => setPmdcNumber(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Clinic Contact Phone</label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Official Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="font-bold text-slate-700">Doctor Bio &amp; Clinical Background (Public Website)</label>
          <textarea
            rows={3}
            value={about}
            onChange={(e) => setAbout(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
      </div>

      {/* SECTION 2: Clinic Locations, Timings & Fees */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">
                Clinic Locations, Timings &amp; Consultation Fees
              </h4>
              <p className="text-[11px] text-slate-500">
                Fully editable by administration without hardcoding
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleAddLocation}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-teal-700 bg-teal-50 hover:bg-teal-100 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Another Clinic Branch
          </button>
        </div>

        <div className="space-y-5">
          {locations.map((loc, idx) => (
            <div
              key={loc.id}
              className="p-5 rounded-2xl border border-slate-200 bg-slate-50/60 space-y-4 relative"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900">
                  Location #{idx + 1}: {loc.name}
                </span>
                {locations.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveLocation(idx)}
                    className="text-rose-600 hover:text-rose-700 font-bold text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Remove
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Clinic Name</label>
                  <input
                    type="text"
                    required
                    value={loc.name}
                    onChange={(e) => handleUpdateLocation(idx, 'name', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Days of Operation</label>
                  <input
                    type="text"
                    placeholder="e.g. Monday to Saturday"
                    value={loc.days}
                    onChange={(e) => handleUpdateLocation(idx, 'days', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Session Timings</label>
                  <input
                    type="text"
                    placeholder="e.g. 05:30 PM – 09:30 PM"
                    value={loc.timings}
                    onChange={(e) => handleUpdateLocation(idx, 'timings', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Physical Address / Landmark</label>
                  <input
                    type="text"
                    required
                    value={loc.address}
                    onChange={(e) => handleUpdateLocation(idx, 'address', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Consultation Fee (PKR)</label>
                  <input
                    type="number"
                    value={loc.fee}
                    onChange={(e) => handleUpdateLocation(idx, 'fee', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 3: Scheduling & Emergency */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
        <h4 className="font-bold text-sm text-slate-900 pb-2 border-b border-slate-100">
          Appointment Slotting &amp; Emergency Protocols
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Slot Interval (Minutes)</label>
            <input
              type="number"
              value={intervalMinutes}
              onChange={(e) => setIntervalMinutes(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Max Capacity Per Slot</label>
            <input
              type="number"
              value={maxPerSlot}
              onChange={(e) => setMaxPerSlot(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Emergency Desk Contact</label>
            <input
              type="text"
              value={emergencyContact}
              onChange={(e) => setEmergencyContact(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
            />
          </div>
        </div>
      </div>

      {/* Bottom Save bar */}
      <div className="flex justify-end gap-3 pt-2">
        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-xs text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-50 shadow-md cursor-pointer"
        >
          <Save className="w-4 h-4" />
          {saving ? 'Updating System...' : 'Save All Settings'}
        </button>
      </div>
    </form>
  );
};
