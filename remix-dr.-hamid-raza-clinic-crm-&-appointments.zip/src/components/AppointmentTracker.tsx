import React, { useState, useEffect } from 'react';
import {
  X,
  Search,
  CheckCircle2,
  Clock,
  Calendar,
  Building2,
  AlertCircle,
  Activity,
  User,
  Phone,
  FileCheck,
  ChevronRight,
} from 'lucide-react';
import { Appointment, ClinicSettings } from '../types/clinic';
import { api } from '../services/api';

interface AppointmentTrackerProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ClinicSettings;
  initialQuery?: string;
}

export const AppointmentTracker: React.FC<AppointmentTrackerProps> = ({
  isOpen,
  onClose,
  settings,
  initialQuery = '',
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Appointment[]>([]);
  const [searched, setSearched] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      handleSearch(initialQuery);
    }
  }, [initialQuery]);

  if (!isOpen) return null;

  const handleSearch = async (overrideQ?: string) => {
    const q = (overrideQ !== undefined ? overrideQ : query).trim();
    if (!q) {
      setErrorMsg('Please enter a booking reference (e.g. HR-8101) or phone number');
      return;
    }
    setErrorMsg('');
    setLoading(true);
    setSearched(true);

    try {
      const data = await api.lookupAppointments(q);
      setResults(data);
    } catch (err: any) {
      setErrorMsg('Failed to lookup appointment: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: Appointment['status']) => {
    switch (status) {
      case 'in-consultation':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300 animate-pulse">
            <Activity className="w-3.5 h-3.5" />
            Currently with Doctor
          </span>
        );
      case 'in-queue':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">
            <Clock className="w-3.5 h-3.5" />
            In Waiting Room (Ready)
          </span>
        );
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Confirmed &amp; Scheduled
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <FileCheck className="w-3.5 h-3.5" />
            Consultation Completed
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">
            Cancelled
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden relative animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-800 to-slate-900 text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-700/80 flex items-center justify-center">
              <Search className="w-5 h-5 text-teal-200" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Live Appointment &amp; Queue Tracker
              </h3>
              <p className="text-xs text-teal-200/80">
                Dr. Hamid Raza Pediatric Consultation Desk
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search input */}
        <div className="p-6 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">
              Enter Booking Reference (e.g. HR-8101) or Guardian Phone
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. HR-8101 or 03001234567"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 font-semibold"
              />
              <button
                type="button"
                onClick={() => handleSearch()}
                disabled={loading}
                className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
              >
                {loading ? 'Searching...' : 'Check Status'}
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Results List */}
          {searched && (
            <div className="space-y-4 pt-2">
              {results.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">No appointments found</p>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Please check the reference ID or phone number. You can also contact the reception desk directly.
                  </p>
                </div>
              ) : (
                results.map((apt) => {
                  const location = settings.locations.find((l) => l.id === apt.clinicLocationId);
                  return (
                    <div
                      key={apt.id}
                      className="p-5 rounded-2xl border border-slate-200 bg-white shadow-xs space-y-4 hover:border-teal-300 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                            Booking Reference
                          </span>
                          <div className="text-lg font-black text-slate-900 tracking-wider">
                            {apt.bookingReference}
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                            Daily Token
                          </span>
                          <span className="text-2xl font-black text-teal-700">
                            #{String(apt.tokenNumber).padStart(2, '0')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        {getStatusBadge(apt.status)}
                        <span className="text-xs font-semibold text-slate-500">
                          {apt.date} • {apt.timeSlot}
                        </span>
                      </div>

                      {/* Detail points */}
                      <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-slate-50 text-xs">
                        <div>
                          <span className="text-slate-400 text-[10px] block">Patient Name:</span>
                          <span className="font-bold text-slate-800">{apt.patientName}</span>
                          <span className="text-slate-500 text-[10px] block">
                            {apt.patientAgeYears}y {apt.patientAgeMonths}m ({apt.patientGender})
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 text-[10px] block">Guardian:</span>
                          <span className="font-bold text-slate-800">{apt.guardianName}</span>
                          <span className="text-slate-500 text-[10px] block">{apt.guardianPhone}</span>
                        </div>
                        <div className="col-span-2 pt-1 border-t border-slate-200/60">
                          <span className="text-slate-400 text-[10px] block">Location:</span>
                          <span className="font-bold text-slate-800">{location?.name || 'Clinic Center'}</span>
                        </div>
                      </div>

                      {/* Guidance based on status */}
                      {apt.status === 'in-queue' && (
                        <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 flex items-center gap-2">
                          <Clock className="w-4 h-4 text-blue-600 shrink-0" />
                          <span>
                            You are in the waiting queue. Please stay near the consultation room.
                          </span>
                        </div>
                      )}

                      {apt.status === 'in-consultation' && (
                        <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-center gap-2">
                          <Activity className="w-4 h-4 text-amber-600 shrink-0" />
                          <span>Dr. Hamid Raza is currently reviewing this consultation.</span>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
