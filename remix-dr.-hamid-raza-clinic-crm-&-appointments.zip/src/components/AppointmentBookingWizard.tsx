import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Clock,
  User,
  Phone,
  Mail,
  Baby,
  Building2,
  FileText,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
  ChevronLeft,
  Printer,
  Copy,
  Check,
  Search,
} from 'lucide-react';
import { ClinicSettings, Appointment } from '../types/clinic';
import { api } from '../services/api';

interface AppointmentBookingWizardProps {
  settings: ClinicSettings;
  isOpen: boolean;
  onClose: () => void;
  preselectedClinicId?: string;
  preselectedService?: string;
  onBookingSuccess?: (appointment: Appointment) => void;
  onOpenTracker?: (referenceId?: string) => void;
}

export const AppointmentBookingWizard: React.FC<AppointmentBookingWizardProps> = ({
  settings,
  isOpen,
  onClose,
  preselectedClinicId,
  preselectedService,
  onBookingSuccess,
  onOpenTracker,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [selectedClinicId, setSelectedClinicId] = useState<string>(
    preselectedClinicId || settings.locations[0]?.id || ''
  );

  // Default to tomorrow or today
  const getTodayISO = () => new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(getTodayISO());
  const [availableSlots, setAvailableSlots] = useState<
    Array<{ time: string; available: boolean; bookedCount: number; maxCapacity: number }>
  >([]);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');
  const [loadingSlots, setLoadingSlots] = useState<boolean>(false);

  // Child / Guardian details
  const [patientName, setPatientName] = useState('');
  const [patientAgeYears, setPatientAgeYears] = useState<number>(1);
  const [patientAgeMonths, setPatientAgeMonths] = useState<number>(0);
  const [patientGender, setPatientGender] = useState<'Male' | 'Female'>('Male');
  const [guardianName, setGuardianName] = useState('');
  const [guardianRelation, setGuardianRelation] = useState<'Father' | 'Mother' | 'Guardian'>('Father');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [guardianEmail, setGuardianEmail] = useState('');
  const [reasonForVisit, setReasonForVisit] = useState(preselectedService || '');
  const [isFollowUp, setIsFollowUp] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  // Keep clinic selection updated if prop changes
  useEffect(() => {
    if (preselectedClinicId) {
      setSelectedClinicId(preselectedClinicId);
    }
  }, [preselectedClinicId]);

  useEffect(() => {
    if (preselectedService) {
      setReasonForVisit(preselectedService);
    }
  }, [preselectedService]);

  // Fetch slots whenever clinic or date changes
  useEffect(() => {
    if (!selectedClinicId || !selectedDate) return;
    setLoadingSlots(true);
    api
      .getSlots(selectedDate, selectedClinicId)
      .then((res) => {
        setAvailableSlots(res.slots || []);
        if (res.slots?.length > 0 && res.slots[0].available) {
          setSelectedTimeSlot(res.slots[0].time);
        } else {
          const firstAvail = res.slots?.find((s) => s.available);
          setSelectedTimeSlot(firstAvail ? firstAvail.time : '');
        }
      })
      .catch((err) => {
        console.error('Failed to load slots:', err);
      })
      .finally(() => {
        setLoadingSlots(false);
      });
  }, [selectedClinicId, selectedDate]);

  if (!isOpen) return null;

  const selectedLocation = settings.locations.find((l) => l.id === selectedClinicId);

  const handleStep1Next = () => {
    if (!selectedClinicId) {
      setErrorMsg('Please select a clinic location');
      return;
    }
    setErrorMsg('');
    setStep(2);
  };

  const handleStep2Next = () => {
    if (!selectedTimeSlot) {
      setErrorMsg('Please select a consultation time slot');
      return;
    }
    setErrorMsg('');
    setStep(3);
  };

  const handleSubmitBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!patientName.trim()) {
      setErrorMsg("Please enter the child's name");
      return;
    }
    if (!guardianName.trim()) {
      setErrorMsg('Please enter parent/guardian name');
      return;
    }
    if (!guardianPhone.trim() || guardianPhone.trim().length < 9) {
      setErrorMsg('Please provide a valid phone or WhatsApp number');
      return;
    }

    setSubmitting(true);
    try {
      const apt = await api.createAppointment({
        patientName: patientName.trim(),
        patientAgeYears: Number(patientAgeYears) || 0,
        patientAgeMonths: Number(patientAgeMonths) || 0,
        patientGender,
        guardianName: guardianName.trim(),
        guardianRelation,
        guardianPhone: guardianPhone.trim(),
        guardianEmail: guardianEmail.trim(),
        clinicLocationId: selectedClinicId,
        date: selectedDate,
        timeSlot: selectedTimeSlot,
        reasonForVisit: reasonForVisit.trim() || 'General Pediatric Checkup',
        isFollowUp,
        fee: selectedLocation?.fee || 0,
      });

      setConfirmedAppointment(apt);
      setStep(4);
      if (onBookingSuccess) onBookingSuccess(apt);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to complete booking. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCopyCode = () => {
    if (!confirmedAppointment) return;
    navigator.clipboard.writeText(confirmedAppointment.bookingReference);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handlePrintSlip = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden relative animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-800 to-teal-900 text-white px-6 py-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-teal-300 uppercase tracking-wider">
                Online Appointment Desk
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
              <span className="text-xs text-teal-100">Dr. Hamid Raza</span>
            </div>
            <h3 className="text-lg font-bold text-white mt-0.5">
              {step === 4 ? 'Appointment Confirmed & Token Issued' : 'Schedule a Pediatric Consultation'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar (when not confirmed) */}
        {step < 4 && (
          <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs font-semibold">
            <div className={`flex items-center gap-1.5 ${step >= 1 ? 'text-teal-700 font-bold' : 'text-slate-400'}`}>
              <span className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center text-[11px]">1</span>
              <span>Clinic</span>
            </div>
            <div className="w-8 h-0.5 bg-slate-200" />
            <div className={`flex items-center gap-1.5 ${step >= 2 ? 'text-teal-700 font-bold' : 'text-slate-400'}`}>
              <span className={`w-5 h-5 rounded-full ${step >= 2 ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-500'} flex items-center justify-center text-[11px]`}>2</span>
              <span>Date &amp; Slot</span>
            </div>
            <div className="w-8 h-0.5 bg-slate-200" />
            <div className={`flex items-center gap-1.5 ${step >= 3 ? 'text-teal-700 font-bold' : 'text-slate-400'}`}>
              <span className={`w-5 h-5 rounded-full ${step >= 3 ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-500'} flex items-center justify-center text-[11px]`}>3</span>
              <span>Child Info</span>
            </div>
          </div>
        )}

        {/* Error Notification */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-700 text-xs font-semibold">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* STEP 1: Select Clinic Location */}
        {step === 1 && (
          <div className="p-6 space-y-5">
            <div>
              <h4 className="text-sm font-bold text-slate-900 mb-1">
                Select Consultation Center
              </h4>
              <p className="text-xs text-slate-500">
                Choose between Dr. Hamid Raza's institutional hospital OPD or private executive clinic.
              </p>
            </div>

            <div className="space-y-3">
              {settings.locations.map((loc) => {
                const isSelected = selectedClinicId === loc.id;
                return (
                  <div
                    key={loc.id}
                    onClick={() => setSelectedClinicId(loc.id)}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                      isSelected
                        ? 'border-teal-600 bg-teal-50/50 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">{loc.name}</span>
                          {loc.isDefault && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800">
                              Primary
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 line-clamp-1">{loc.address}</p>
                        <div className="flex flex-wrap items-center gap-3 pt-2 text-[11px] font-semibold text-slate-600">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-teal-600" />
                            {loc.days}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1 text-teal-800">
                            <Clock className="w-3.5 h-3.5 text-teal-600" />
                            {loc.timings}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xs font-extrabold text-slate-900">
                          {loc.fee === 0 ? 'Free / Subsidized' : `Rs. ${loc.fee}`}
                        </div>
                        <div className="text-[10px] text-slate-400">Consultation Fee</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                onClick={handleStep1Next}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-xs text-white bg-teal-600 hover:bg-teal-700 shadow-md cursor-pointer transition-all"
              >
                <span>Continue to Date &amp; Slots</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Select Date & Slot */}
        {step === 2 && (
          <div className="p-6 space-y-5">
            <div>
              <h4 className="text-sm font-bold text-slate-900 mb-1">
                Select Date &amp; Available Slot
              </h4>
              <p className="text-xs text-slate-500">
                Clinic: <strong className="text-slate-800">{selectedLocation?.name}</strong>
              </p>
            </div>

            {/* Date Picker Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Appointment Date</label>
              <input
                type="date"
                min={getTodayISO()}
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 font-semibold"
              />
            </div>

            {/* Slots Grid */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span>Available Consultation Slots</span>
                {loadingSlots && <span className="text-teal-600 animate-pulse">Checking capacity...</span>}
              </div>

              {loadingSlots ? (
                <div className="p-8 text-center text-xs text-slate-400">Loading schedule...</div>
              ) : availableSlots.length === 0 ? (
                <div className="p-6 rounded-xl bg-slate-50 text-center text-xs text-slate-500">
                  No slots currently scheduled for this date. Please select another date.
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 max-h-56 overflow-y-auto p-1">
                  {availableSlots.map((slot) => {
                    const isSelected = selectedTimeSlot === slot.time;
                    return (
                      <button
                        key={slot.time}
                        type="button"
                        disabled={!slot.available}
                        onClick={() => setSelectedTimeSlot(slot.time)}
                        className={`p-2.5 rounded-xl text-xs font-bold transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                          isSelected
                            ? 'bg-teal-600 text-white shadow-sm ring-2 ring-teal-600'
                            : slot.available
                            ? 'bg-slate-50 hover:bg-teal-50 text-slate-800 border border-slate-200'
                            : 'bg-slate-100 text-slate-300 border border-slate-200 cursor-not-allowed opacity-50'
                        }`}
                      >
                        <span>{slot.time}</span>
                        <span className={`text-[10px] font-normal ${isSelected ? 'text-teal-100' : 'text-slate-400'}`}>
                          {slot.available ? `${slot.maxCapacity - slot.bookedCount} spot(s)` : 'Full'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <button
                onClick={() => setStep(1)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                Back
              </button>
              <button
                onClick={handleStep2Next}
                disabled={!selectedTimeSlot}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 shadow-md cursor-pointer transition-all"
              >
                <span>Enter Patient Details</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Patient & Guardian Information */}
        {step === 3 && (
          <form onSubmit={handleSubmitBooking} className="p-6 space-y-4">
            <div>
              <h4 className="text-sm font-bold text-slate-900 mb-0.5">
                Child &amp; Guardian Information
              </h4>
              <p className="text-xs text-slate-500">
                Please provide accurate details for clinical records and prescription generation.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Child's Full Name *</label>
                <div className="relative">
                  <Baby className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Muhammad Hamza"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Gender *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPatientGender('Male')}
                    className={`py-2 text-xs font-bold rounded-xl border ${
                      patientGender === 'Male'
                        ? 'border-teal-600 bg-teal-50 text-teal-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Boy (Male)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPatientGender('Female')}
                    className={`py-2 text-xs font-bold rounded-xl border ${
                      patientGender === 'Female'
                        ? 'border-teal-600 bg-teal-50 text-teal-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Girl (Female)
                  </button>
                </div>
              </div>
            </div>

            {/* Age in Years & Months */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Age: Years</label>
                <select
                  value={patientAgeYears}
                  onChange={(e) => setPatientAgeYears(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                >
                  {Array.from({ length: 18 }, (_, i) => (
                    <option key={i} value={i}>
                      {i === 0 ? '0 Years (Infant)' : `${i} Years`}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Age: Months</label>
                <select
                  value={patientAgeMonths}
                  onChange={(e) => setPatientAgeMonths(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                >
                  {Array.from({ length: 12 }, (_, i) => (
                    <option key={i} value={i}>
                      {i} Month(s)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Parent Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Guardian / Parent Name *</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Tariq Mehmood"
                    value={guardianName}
                    onChange={(e) => setGuardianName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Relationship</label>
                <select
                  value={guardianRelation}
                  onChange={(e) => setGuardianRelation(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                >
                  <option value="Father">Father</option>
                  <option value="Mother">Mother</option>
                  <option value="Guardian">Guardian</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">WhatsApp / Mobile Number *</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    placeholder="0300-1234567"
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Email Address (Optional)</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    placeholder="parent@email.com"
                    value={guardianEmail}
                    onChange={(e) => setGuardianEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>
            </div>

            {/* Reason for visit */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Reason for Visit / Symptoms
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Fever for 2 days, chest wheezing, routine vaccination, or poor feeding"
                value={reasonForVisit}
                onChange={(e) => setReasonForVisit(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Follow-up flag */}
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={isFollowUp}
                onChange={(e) => setIsFollowUp(e.target.checked)}
                className="rounded text-teal-600 focus:ring-teal-500"
              />
              <span>This is a follow-up consultation within 7 days of previous visit</span>
            </label>

            {/* Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                Back
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center gap-2 px-7 py-3 rounded-xl font-bold text-xs text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 shadow-md cursor-pointer transition-all"
              >
                {submitting ? 'Confirming Token...' : 'Confirm Appointment'}
              </button>
            </div>
          </form>
        )}

        {/* STEP 4: Success & Printable Token Slip */}
        {step === 4 && confirmedAppointment && (
          <div className="p-6 space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-xs">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="text-xl font-black text-slate-900">
                Appointment Successfully Reserved!
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Your queue token has been generated. Please keep this token slip or booking reference for your clinic visit.
              </p>
            </div>

            {/* Digital Token Pass Card */}
            <div className="bg-gradient-to-br from-slate-900 to-teal-950 rounded-2xl p-5 text-white shadow-lg space-y-4 relative overflow-hidden">
              <div className="flex items-start justify-between border-b border-white/10 pb-3">
                <div>
                  <div className="text-xs font-bold text-teal-300">Dr. Hamid Raza</div>
                  <div className="text-[11px] text-teal-100">Consultant Child Specialist &amp; Neonatologist</div>
                  <div className="text-[10px] text-teal-200/70">Senior Registrar Mayo Hospital Lahore</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-teal-300">Daily Queue Token</div>
                  <div className="text-3xl font-black text-teal-200">
                    #{String(confirmedAppointment.tokenNumber).padStart(2, '0')}
                  </div>
                </div>
              </div>

              {/* Reference ID Pill */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/10 border border-white/15">
                <div>
                  <div className="text-[10px] text-teal-200 font-bold uppercase tracking-wider">
                    Booking Reference ID
                  </div>
                  <div className="text-lg font-black tracking-widest text-white">
                    {confirmedAppointment.bookingReference}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 rounded-lg bg-teal-500/30 hover:bg-teal-500/50 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Appointment specifics */}
              <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                <div>
                  <span className="text-[11px] text-teal-200/70 block">Child Patient:</span>
                  <span className="font-bold text-white">{confirmedAppointment.patientName}</span>
                  <span className="text-[10px] text-teal-200 block">
                    {confirmedAppointment.patientAgeYears}y {confirmedAppointment.patientAgeMonths}m ({confirmedAppointment.patientGender})
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-teal-200/70 block">Guardian:</span>
                  <span className="font-bold text-white">{confirmedAppointment.guardianName}</span>
                  <span className="text-[10px] text-teal-200 block">{confirmedAppointment.guardianPhone}</span>
                </div>
                <div>
                  <span className="text-[11px] text-teal-200/70 block">Date &amp; Time:</span>
                  <span className="font-bold text-white">
                    {confirmedAppointment.date} at {confirmedAppointment.timeSlot}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-teal-200/70 block">Clinic Location:</span>
                  <span className="font-bold text-white line-clamp-1">{selectedLocation?.name}</span>
                </div>
              </div>
            </div>

            {/* Visit Instructions */}
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-700" />
                Clinic Guidelines
              </div>
              <ul className="list-disc list-inside text-[11px] space-y-0.5 text-amber-800">
                <li>Please arrive at the clinic reception 10 minutes before your scheduled slot.</li>
                <li>Bring your child's previous vaccination yellow card and medical discharge slips.</li>
                <li>You can track live doctor queue progress using your booking reference {confirmedAppointment.bookingReference}.</li>
              </ul>
            </div>

            {/* Action buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handlePrintSlip}
                className="flex-1 py-3 px-4 rounded-xl font-bold text-xs text-slate-800 bg-slate-100 hover:bg-slate-200 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                Print Token Slip
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  if (onOpenTracker) onOpenTracker(confirmedAppointment.bookingReference);
                }}
                className="flex-1 py-3 px-4 rounded-xl font-bold text-xs text-white bg-teal-600 hover:bg-teal-700 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Search className="w-4 h-4" />
                Track Queue Status
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
