import React from 'react';
import {
  Award,
  BookOpen,
  GraduationCap,
  Building2,
  ShieldCheck,
  Stethoscope,
  HeartHandshake,
  CheckCircle,
  FileText,
  Calendar,
} from 'lucide-react';
import { ClinicSettings } from '../types/clinic';

interface DoctorProfileSectionProps {
  settings: ClinicSettings;
  onOpenBooking: () => void;
}

export const DoctorProfileSection: React.FC<DoctorProfileSectionProps> = ({
  settings,
  onOpenBooking,
}) => {
  return (
    <section id="profile" className="py-20 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-teal-50 text-teal-700 border border-teal-200">
            <GraduationCap className="w-4 h-4 text-teal-600" />
            <span>Consultant Clinical Profile</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Meet Dr. Hamid Raza
          </h2>
          <p className="text-base sm:text-lg text-slate-600">
            Senior Registrar at Mayo Hospital Lahore, dedicated to providing compassionate, evidence-based pediatric and neonatal medical care.
          </p>
        </div>

        {/* Profile Card & Details Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Doctor credentials card */}
          <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="relative space-y-6">
              {/* Doctor Avatar / Badge */}
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white font-extrabold text-3xl shadow-lg border-2 border-teal-200/40">
                  HR
                </div>
                <div>
                  <h3 className="text-2xl font-black tracking-tight text-white">
                    {settings.doctor.name}
                  </h3>
                  <p className="text-sm font-semibold text-teal-300">
                    {settings.doctor.specialization}
                  </p>
                  <p className="text-xs text-teal-200/70">
                    {settings.doctor.hospitalAffiliation}
                  </p>
                </div>
              </div>

              {/* Degrees & Qualifications */}
              <div className="space-y-3 pt-2">
                <div className="text-xs font-bold uppercase tracking-wider text-teal-300">
                  Medical Qualifications
                </div>
                <div className="space-y-2">
                  <div className="p-3 rounded-xl bg-white/10 backdrop-blur-xs border border-white/15">
                    <div className="font-bold text-sm text-white">
                      MD Pediatrics (Doctor of Medicine)
                    </div>
                    <div className="text-xs text-teal-200">
                      King Edward Medical University (KE) / Mayo Hospital Lahore
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/10 backdrop-blur-xs border border-white/15">
                    <div className="font-bold text-sm text-white">
                      M.B.B.S. (Bachelor of Medicine &amp; Surgery)
                    </div>
                    <div className="text-xs text-teal-200">
                      King Edward Medical University (KE), Lahore
                    </div>
                  </div>
                </div>
              </div>

              {/* Current Institutional Appointment */}
              <div className="pt-2 border-t border-white/10 space-y-2 text-xs">
                <div className="flex items-start gap-2.5 text-teal-100">
                  <Building2 className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white">Senior Registrar:</span> Department of Pediatrics &amp; Neonatology, Mayo Hospital Lahore.
                  </div>
                </div>
                <div className="flex items-start gap-2.5 text-teal-100">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white">Registration:</span> {settings.doctor.pmdcNumber}
                  </div>
                </div>
              </div>

              <button
                onClick={onOpenBooking}
                className="w-full py-3.5 rounded-xl font-bold text-sm text-slate-900 bg-teal-300 hover:bg-teal-200 shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer mt-4"
              >
                <Calendar className="w-4 h-4 text-slate-900" />
                Book Consultation with Dr. Hamid
              </button>
            </div>
          </div>

          {/* Right Column: In-depth clinical background */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-slate-900">
                Dedicated Child Healthcare &amp; Neonatal Excellence
              </h3>
              <p className="text-slate-600 leading-relaxed text-base">
                {settings.doctor.about}
              </p>
              <p className="text-slate-600 leading-relaxed text-base">
                With comprehensive clinical training in one of South Asia’s oldest and most prestigious medical institutions—King Edward Medical University and Mayo Hospital Lahore—Dr. Hamid Raza brings rigorous scientific methodology, ethical medical judgment, and deep empathy to pediatric medicine.
              </p>
            </div>

            {/* Core Competencies & Clinical Focus */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-teal-50/50 border border-teal-100 space-y-2">
                <div className="flex items-center gap-2 text-teal-800 font-bold text-sm">
                  <CheckCircle className="w-4 h-4 text-teal-600" />
                  Neonatal Intensive Care (NICU)
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Management of premature infants, neonatal jaundice, birth asphyxia, respiratory distress, and incubator stabilization.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-cyan-50/50 border border-cyan-100 space-y-2">
                <div className="flex items-center gap-2 text-cyan-800 font-bold text-sm">
                  <CheckCircle className="w-4 h-4 text-cyan-600" />
                  Pediatric Pulmonology &amp; Asthma
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Accurate diagnosis of recurrent wheezing, childhood asthma, spacer/inhaler technique training, and allergy mitigation.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
                  <CheckCircle className="w-4 h-4 text-slate-700" />
                  Growth &amp; Nutritional Disorders
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Weight faltering, infant feeding difficulties, vitamin deficiencies, rickets, and WHO percentile milestone tracking.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-100 space-y-2">
                <div className="flex items-center gap-2 text-amber-800 font-bold text-sm">
                  <CheckCircle className="w-4 h-4 text-amber-600" />
                  Infectious Diseases &amp; Fever Workups
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Evidence-based diagnosis and treatment of pediatric typhoid, pneumonia, viral exanthems, Dengue, and gastrointestinal infections.
                </p>
              </div>
            </div>

            {/* Philosophy of Care */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-teal-50 via-white to-slate-50 border border-teal-200/60 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700 shrink-0 mt-0.5">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-slate-900">
                  Conservative, Evidence-Based Pediatric Philosophy
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Dr. Hamid strongly advocates against irrational polypharmacy and excessive antibiotic use in children. Every treatment plan is tailored to the child's exact developmental stage with clear, comforting guidance for worried parents.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
