import React from 'react';
import {
  Calendar,
  Clock,
  ShieldCheck,
  Award,
  Baby,
  Activity,
  HeartPulse,
  MapPin,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Search,
} from 'lucide-react';
import { ClinicSettings } from '../types/clinic';

interface HeroProps {
  settings: ClinicSettings;
  onOpenBooking: () => void;
  onOpenTracker: () => void;
  onNavigate: (section: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  settings,
  onOpenBooking,
  onOpenTracker,
  onNavigate,
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-teal-50/70 via-white to-slate-50 pt-10 pb-20">
      {/* Decorative ambient elements */}
      <div className="absolute top-0 right-10 -z-10 w-96 h-96 bg-teal-200/40 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 -z-10 w-80 h-80 bg-cyan-100/50 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Doctor Profile & Intro */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-100/80 border border-teal-200 text-teal-800 text-xs font-bold tracking-wide">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span>Official Clinic &amp; Appointment Portal</span>
            </div>

            <div className="space-y-3">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12]">
                {settings.doctor.name}
              </h1>
              <p className="text-xl sm:text-2xl font-bold text-teal-700">
                {settings.doctor.specialization}
              </p>
              <div className="flex flex-wrap items-center gap-2 pt-1 text-sm font-semibold text-slate-700">
                <span className="px-3 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                  {settings.doctor.qualifications}
                </span>
                <span className="text-slate-300">•</span>
                <span className="px-3 py-1 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 shadow-2xs font-bold">
                  {settings.doctor.designation}
                </span>
              </div>
            </div>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              Specialized clinical care for newborns, infants, and growing children. Providing evidence-based neonatal intensive care, routine growth monitoring, vaccination, pediatric asthma therapy, and acute illness treatment in Lahore.
            </p>

            {/* Quick Action CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={onOpenBooking}
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl font-bold text-base text-white bg-gradient-to-r from-teal-600 via-teal-700 to-teal-800 hover:from-teal-700 hover:to-teal-900 shadow-lg shadow-teal-700/25 hover:shadow-xl hover:-translate-y-0.5 transition-all cursor-pointer group"
              >
                <Calendar className="w-5 h-5 text-teal-200 group-hover:scale-110 transition-transform" />
                <span>Book an Appointment</span>
                <ArrowRight className="w-4 h-4 text-teal-200 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onOpenTracker}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-xl font-bold text-base text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 shadow-sm hover:shadow transition-all cursor-pointer"
              >
                <Search className="w-4 h-4 text-teal-600" />
                <span>Track Token / Booking</span>
              </button>
            </div>

            {/* Institutional Affiliation Badge & Highlights */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 border-t border-slate-200/70">
              <div className="p-3 bg-white/80 rounded-xl border border-slate-200/80 shadow-2xs">
                <div className="text-xs text-slate-500 font-medium">Institution</div>
                <div className="text-sm font-bold text-slate-900">Mayo Hospital</div>
                <div className="text-[11px] text-teal-700 font-medium">Senior Registrar</div>
              </div>
              <div className="p-3 bg-white/80 rounded-xl border border-slate-200/80 shadow-2xs">
                <div className="text-xs text-slate-500 font-medium">Alma Mater</div>
                <div className="text-sm font-bold text-slate-900">King Edward (KE)</div>
                <div className="text-[11px] text-teal-700 font-medium">MBBS &amp; MD Pediatrics</div>
              </div>
              <div className="p-3 bg-white/80 rounded-xl border border-slate-200/80 shadow-2xs col-span-2 sm:col-span-1">
                <div className="text-xs text-slate-500 font-medium">Certification</div>
                <div className="text-sm font-bold text-emerald-700 flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4" /> PMDC Verified
                </div>
                <div className="text-[11px] text-slate-500">{settings.doctor.pmdcNumber}</div>
              </div>
            </div>
          </div>

          {/* Right Column: Doctor Card & Live Clinic Status */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md">
              {/* Doctor Visual Card */}
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xl shadow-slate-200/50 space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-teal-700 to-cyan-600 flex items-center justify-center text-white shadow-md font-extrabold text-2xl tracking-tight">
                      HR
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-extrabold text-lg text-slate-900">
                          {settings.doctor.name}
                        </h3>
                        <CheckCircle2 className="w-4 h-4 text-teal-600 fill-teal-50" />
                      </div>
                      <p className="text-xs font-bold text-teal-700">
                        Consultant Pediatrician
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {settings.doctor.hospitalAffiliation}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Appointments Open
                    </span>
                  </div>
                </div>

                {/* Key Pediatric Specialization Highlights */}
                <div className="grid grid-cols-2 gap-2.5 text-xs font-semibold text-slate-700">
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-teal-50/60 border border-teal-100/70">
                    <Baby className="w-4 h-4 text-teal-700 shrink-0" />
                    <span>Neonatal ICU Care</span>
                  </div>
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-cyan-50/60 border border-cyan-100/70">
                    <Activity className="w-4 h-4 text-cyan-700 shrink-0" />
                    <span>Growth &amp; Milestones</span>
                  </div>
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-blue-50/60 border border-blue-100/70">
                    <HeartPulse className="w-4 h-4 text-blue-700 shrink-0" />
                    <span>Pediatric Asthma</span>
                  </div>
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-amber-50/60 border border-amber-100/70">
                    <Award className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>EPI Vaccinations</span>
                  </div>
                </div>

                {/* Clinic Timings Overview Card */}
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                    <span className="flex items-center gap-1.5 text-teal-800">
                      <Clock className="w-4 h-4 text-teal-600" />
                      Consultation Sessions
                    </span>
                    <button
                      onClick={() => onNavigate('locations')}
                      className="text-teal-700 hover:underline text-[11px] font-bold"
                    >
                      View All &rarr;
                    </button>
                  </div>

                  <div className="space-y-2 text-xs">
                    {settings.locations.slice(0, 2).map((loc) => (
                      <div
                        key={loc.id}
                        className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200/70"
                      >
                        <div>
                          <div className="font-bold text-slate-800 line-clamp-1">{loc.name}</div>
                          <div className="text-[11px] text-slate-500">{loc.days}</div>
                        </div>
                        <div className="text-right">
                          <span className="inline-block px-2 py-0.5 rounded-md font-bold text-[11px] bg-teal-50 text-teal-800">
                            {loc.timings}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Instant Action Button */}
                <button
                  onClick={onOpenBooking}
                  className="w-full py-3.5 rounded-xl font-bold text-sm text-white bg-teal-700 hover:bg-teal-800 shadow-md shadow-teal-700/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  Select Date &amp; Reserve Token Now
                </button>
              </div>

              {/* Floating trust badge */}
              <div className="absolute -bottom-5 -left-4 sm:-left-6 bg-white rounded-2xl p-3 border border-slate-200 shadow-lg flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 font-extrabold text-sm">
                  12+
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Years Clinical Focus</div>
                  <div className="text-[10px] text-slate-500">Mayo Hospital &amp; Pediatrics</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
