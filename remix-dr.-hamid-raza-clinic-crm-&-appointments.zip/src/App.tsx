import React, { useState, useEffect } from 'react';
import { defaultSettings, ClinicSettings } from '../server/initialData';
import { api } from './services/api';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { DoctorProfileSection } from './components/DoctorProfileSection';
import { PediatricServices } from './components/PediatricServices';
import { ClinicLocationsSection } from './components/ClinicLocationsSection';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { AppointmentBookingWizard } from './components/AppointmentBookingWizard';
import { AppointmentTracker } from './components/AppointmentTracker';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminLayout } from './components/admin/AdminLayout';

export default function App() {
  const [settings, setSettings] = useState<ClinicSettings>(defaultSettings);
  const [loadingSettings, setLoadingSettings] = useState(true);

  // View state
  const [currentView, setCurrentView] = useState<'website' | 'admin'>('website');
  const [activeSection, setActiveSection] = useState('home');

  // Modals
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [preselectedClinicId, setPreselectedClinicId] = useState<string | undefined>(undefined);
  const [preselectedService, setPreselectedService] = useState<string | undefined>(undefined);

  const [trackerModalOpen, setTrackerModalOpen] = useState(false);
  const [trackerQuery, setTrackerQuery] = useState<string>('');

  const [adminLoginOpen, setAdminLoginOpen] = useState(false);

  // Current logged in admin / doctor user
  const [currentUser, setCurrentUser] = useState<{
    username: string;
    name: string;
    role: string;
    designation: string;
  } | null>(() => {
    try {
      const saved = localStorage.getItem('dr_hamid_crm_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Load clinic information & settings on mount
  const loadSettings = async () => {
    try {
      const data = await api.getClinicInfo();
      setSettings(data);
    } catch (err) {
      console.error('Failed to load clinic settings:', err);
    } finally {
      setLoadingSettings(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    if (currentView === 'admin') {
      setCurrentView('website');
    }
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleOpenBooking = (clinicIdOrService?: string) => {
    if (clinicIdOrService) {
      const isLocation = settings.locations.some((l) => l.id === clinicIdOrService);
      if (isLocation) {
        setPreselectedClinicId(clinicIdOrService);
        setPreselectedService(undefined);
      } else {
        setPreselectedService(clinicIdOrService);
        setPreselectedClinicId(undefined);
      }
    } else {
      setPreselectedClinicId(undefined);
      setPreselectedService(undefined);
    }
    setBookingModalOpen(true);
  };

  const handleOpenTracker = (referenceId?: string) => {
    if (referenceId) {
      setTrackerQuery(referenceId);
    }
    setTrackerModalOpen(true);
  };

  const handleOpenAdmin = () => {
    if (currentUser) {
      setCurrentView('admin');
    } else {
      setAdminLoginOpen(true);
    }
  };

  const handleLoginSuccess = (user: {
    username: string;
    name: string;
    role: string;
    designation: string;
  }) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('dr_hamid_crm_user', JSON.stringify(user));
    } catch {
      // storage unavailable
    }
    setCurrentView('admin');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem('dr_hamid_crm_user');
    } catch {
      // ignore
    }
    setCurrentView('website');
  };

  // If in Admin CRM mode, render the Admin Portal
  if (currentView === 'admin' && currentUser) {
    return (
      <AdminLayout
        settings={settings}
        onSettingsUpdated={(newSettings) => setSettings(newSettings)}
        currentUser={currentUser}
        onLogout={handleLogout}
        onReturnToWebsite={() => setCurrentView('website')}
      />
    );
  }

  // Otherwise, render Public Doctor Website / Patient Panel
  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans antialiased selection:bg-teal-500 selection:text-white flex flex-col">
      {/* Top Navbar */}
      <Navbar
        settings={settings}
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenBooking={() => handleOpenBooking()}
        onOpenTracker={() => handleOpenTracker()}
        onOpenAdmin={handleOpenAdmin}
        isAdminLoggedIn={Boolean(currentUser)}
        currentUser={currentUser}
      />

      {/* Main Public Website Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          settings={settings}
          onOpenBooking={() => handleOpenBooking()}
          onOpenTracker={() => handleOpenTracker()}
          onNavigate={handleNavigate}
        />

        {/* Doctor Profile & Credentials Section */}
        <DoctorProfileSection
          settings={settings}
          onOpenBooking={() => handleOpenBooking()}
        />

        {/* Pediatric & Neonatal Services Section */}
        <PediatricServices
          onOpenBooking={(serviceName) => handleOpenBooking(serviceName)}
        />

        {/* Clinic Centers, Timings & Fees Section */}
        <ClinicLocationsSection
          settings={settings}
          onSelectClinicForBooking={(clinicId) => handleOpenBooking(clinicId)}
        />

        {/* Frequently Asked Questions */}
        <FAQSection
          settings={settings}
          onOpenBooking={() => handleOpenBooking()}
        />
      </main>

      {/* Footer */}
      <Footer
        settings={settings}
        onNavigate={handleNavigate}
        onOpenBooking={() => handleOpenBooking()}
        onOpenAdmin={handleOpenAdmin}
        onOpenTracker={() => handleOpenTracker()}
      />

      {/* Appointment Booking Wizard Modal */}
      {bookingModalOpen && (
        <AppointmentBookingWizard
          settings={settings}
          isOpen={bookingModalOpen}
          onClose={() => setBookingModalOpen(false)}
          preselectedClinicId={preselectedClinicId}
          preselectedService={preselectedService}
          onOpenTracker={(refId) => handleOpenTracker(refId)}
        />
      )}

      {/* Live Appointment & Queue Tracker Modal */}
      {trackerModalOpen && (
        <AppointmentTracker
          isOpen={trackerModalOpen}
          onClose={() => {
            setTrackerModalOpen(false);
            setTrackerQuery('');
          }}
          settings={settings}
          initialQuery={trackerQuery}
        />
      )}

      {/* Doctor & Staff Login Modal */}
      {adminLoginOpen && (
        <AdminLoginModal
          isOpen={adminLoginOpen}
          onClose={() => setAdminLoginOpen(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      )}
    </div>
  );
}
