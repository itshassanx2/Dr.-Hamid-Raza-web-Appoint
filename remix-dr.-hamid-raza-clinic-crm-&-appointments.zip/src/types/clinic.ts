export interface DoctorProfile {
  name: string;
  qualifications: string;
  specialization: string;
  designation: string;
  hospitalAffiliation: string;
  about: string;
  experienceYears: number;
  pmdcNumber: string;
  phone: string;
  email: string;
}

export interface ClinicLocation {
  id: string;
  name: string;
  tagline: string;
  address: string;
  city: string;
  days: string;
  timings: string;
  fee: number;
  phone: string;
  isDefault: boolean;
  type: 'hospital' | 'private_clinic' | 'telehealth';
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'General' | 'Appointments' | 'Vaccination' | 'Newborn Care';
}

export interface ClinicSettings {
  doctor: DoctorProfile;
  locations: ClinicLocation[];
  appointmentIntervalMinutes: number;
  maxPatientsPerSlot: number;
  emergencyContact: string;
  faqs: FAQItem[];
}

export interface Appointment {
  id: string;
  bookingReference: string;
  tokenNumber: number;
  patientId?: string;
  patientName: string;
  patientAgeYears: number;
  patientAgeMonths: number;
  patientGender: 'Male' | 'Female';
  guardianName: string;
  guardianRelation: 'Father' | 'Mother' | 'Guardian';
  guardianPhone: string;
  guardianEmail?: string;
  clinicLocationId: string;
  date: string;
  timeSlot: string;
  reasonForVisit: string;
  isFollowUp: boolean;
  status: 'confirmed' | 'in-queue' | 'in-consultation' | 'completed' | 'cancelled' | 'no-show';
  paymentStatus: 'pending' | 'paid' | 'waived';
  fee: number;
  notes?: string;
  createdAt: string;
}

export interface Patient {
  id: string;
  mrn: string;
  childName: string;
  dob: string;
  gender: 'Male' | 'Female';
  bloodGroup: string;
  allergies: string[];
  guardianName: string;
  guardianPhone: string;
  address: string;
  birthWeightKg?: number;
  gestationalWeeks?: number;
  historyNotes: string;
  createdAt: string;
}

export interface Vitals {
  weightKg?: number;
  heightCm?: number;
  headCircumferenceCm?: number;
  temperatureF?: number;
  spo2?: number;
  respiratoryRate?: number;
  heartRate?: number;
}

export interface Medication {
  medicineName: string;
  form: 'Syrup' | 'Drops' | 'Suspension' | 'Sachet' | 'Tablet' | 'Inhaler' | 'Ointment' | 'Respules';
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
}

export interface Prescription {
  id: string;
  prescriptionNumber: string;
  appointmentId?: string;
  patientId: string;
  patientName: string;
  ageDisplay: string;
  gender: 'Male' | 'Female';
  guardianName: string;
  date: string;
  vitals: Vitals;
  chiefComplaints: string[];
  diagnosis: string;
  clinicalNotes?: string;
  medications: Medication[];
  advice: string[];
  investigations?: string[];
  followUpDate?: string;
  doctorName: string;
  doctorDesignation: string;
  createdAt: string;
}

export interface VaccineRecord {
  id: string;
  patientId: string;
  vaccineName: string;
  targetAge: string;
  dueDate: string;
  administeredDate?: string;
  status: 'pending' | 'completed' | 'delayed' | 'skipped';
  batchNo?: string;
  notes?: string;
}

export interface ClinicStats {
  totalPatients: number;
  todayAppointments: number;
  inQueueCount: number;
  completedTodayCount: number;
  currentConsultation: Appointment | null;
  todayRevenue: number;
  totalPrescriptions: number;
}
