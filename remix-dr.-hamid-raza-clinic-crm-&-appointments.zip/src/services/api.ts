import {
  ClinicSettings,
  Appointment,
  Patient,
  Prescription,
  VaccineRecord,
  ClinicStats,
} from '../types/clinic';

export const api = {
  // Settings & Doctor Info
  async getClinicInfo(): Promise<ClinicSettings> {
    const res = await fetch('/api/clinic-info');
    if (!res.ok) throw new Error('Failed to load clinic information');
    return res.json();
  },

  async updateClinicInfo(settings: Partial<ClinicSettings>): Promise<ClinicSettings> {
    const res = await fetch('/api/clinic-info', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to update clinic settings');
    return res.json();
  },

  // Appointments
  async getAppointments(filters?: {
    date?: string;
    clinicId?: string;
    status?: string;
    search?: string;
  }): Promise<Appointment[]> {
    const params = new URLSearchParams();
    if (filters?.date) params.append('date', filters.date);
    if (filters?.clinicId) params.append('clinicId', filters.clinicId);
    if (filters?.status) params.append('status', filters.status);
    if (filters?.search) params.append('search', filters.search);

    const res = await fetch(`/api/appointments?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch appointments');
    return res.json();
  },

  async lookupAppointments(query: string): Promise<Appointment[]> {
    const res = await fetch(`/api/appointments/lookup?q=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error('Failed to lookup appointment');
    return res.json();
  },

  async createAppointment(data: Partial<Appointment>): Promise<Appointment> {
    const res = await fetch('/api/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to book appointment');
    }
    return res.json();
  },

  async updateAppointment(id: string, updates: Partial<Appointment>): Promise<Appointment> {
    const res = await fetch(`/api/appointments/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update appointment');
    return res.json();
  },

  async deleteAppointment(id: string): Promise<void> {
    const res = await fetch(`/api/appointments/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to cancel appointment');
  },

  async getSlots(date: string, clinicLocationId: string): Promise<{
    slots: Array<{ time: string; available: boolean; bookedCount: number; maxCapacity: number }>;
  }> {
    const res = await fetch(
      `/api/slots?date=${encodeURIComponent(date)}&clinicLocationId=${encodeURIComponent(clinicLocationId)}`
    );
    if (!res.ok) throw new Error('Failed to fetch time slots');
    return res.json();
  },

  // Patients
  async getPatients(search?: string): Promise<Patient[]> {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    const res = await fetch(`/api/patients?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to load patient records');
    return res.json();
  },

  async getPatientDetails(id: string): Promise<{
    patient: Patient;
    prescriptions: Prescription[];
    vaccinations: VaccineRecord[];
    appointments: Appointment[];
  }> {
    const res = await fetch(`/api/patients/${id}`);
    if (!res.ok) throw new Error('Failed to load patient profile');
    return res.json();
  },

  async createPatient(data: Partial<Patient>): Promise<Patient> {
    const res = await fetch('/api/patients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to create patient');
    return res.json();
  },

  async updatePatient(id: string, updates: Partial<Patient>): Promise<Patient> {
    const res = await fetch(`/api/patients/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update patient');
    return res.json();
  },

  // Prescriptions
  async getPrescriptions(patientId?: string): Promise<Prescription[]> {
    const url = patientId ? `/api/prescriptions?patientId=${patientId}` : '/api/prescriptions';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to load prescriptions');
    return res.json();
  },

  async createPrescription(data: Partial<Prescription>): Promise<Prescription> {
    const res = await fetch('/api/prescriptions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to generate prescription');
    return res.json();
  },

  // Vaccinations
  async getVaccinations(patientId: string): Promise<VaccineRecord[]> {
    const res = await fetch(`/api/vaccinations/${patientId}`);
    if (!res.ok) throw new Error('Failed to load vaccination records');
    return res.json();
  },

  async recordVaccination(data: Partial<VaccineRecord>): Promise<VaccineRecord> {
    const res = await fetch('/api/vaccinations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to record vaccine');
    return res.json();
  },

  async updateVaccination(id: string, updates: Partial<VaccineRecord>): Promise<VaccineRecord> {
    const res = await fetch(`/api/vaccinations/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update vaccination');
    return res.json();
  },

  // Stats
  async getStats(): Promise<ClinicStats> {
    const res = await fetch('/api/stats');
    if (!res.ok) throw new Error('Failed to load stats');
    return res.json();
  },

  // Auth
  async login(username: string, password: string): Promise<{ success: boolean; user: any; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Invalid credentials');
    }
    return res.json();
  },
};
